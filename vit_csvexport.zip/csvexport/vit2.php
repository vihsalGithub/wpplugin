<style type="text/css" rel="http://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css"></style>

<?php
/*
Plugin Name: VIT Csv Expost
Plugin URI: http://vitwebdevelopment.com/
Description: this is test
Author: VIT2
Version: 1.7.1
*/
class CSVExport
{
    /**
    * Constructor
    */

    public function __construct()
    {
        if(isset($_POST['download_report']))
        {
        $csv = $this->generate_csv();
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private", false);
        header("Content-Type: application/octet-stream");
        header("Content-Disposition: attachment; filename=\"report.csv\";" );
        header("Content-Transfer-Encoding: binary");
        echo $csv;
        exit;
        }



         if(isset($_POST['csvExportByData'])){
              $intialDate =  $_POST['intialDate'];
              $finalDate =  $_POST['finalDate'];


              //echo $intialDate.'__'.$finalDate ;  die;

              global $wpdb;
                $post_id = $wpdb->get_results("SELECT * FROM `{$wpdb->prefix}woocommerce_order_items` where  `order_item_type`='line_item'");
                    $csv_header = '';
                    $csv_header .= 'Customer Name'. ',';
                    $csv_header .= 'Customer Email'. ',';
                    $csv_header .= 'Customer Address'. ',';
                    $csv_header .= 'Shiping Address'. ',';
                    $csv_header .= '#Order Id'. ',';
                    $csv_header .= 'Product id'. ',';
                    $csv_header .= 'Product Name'. ',';
                    $csv_header .= 'Quantity'. ',';
                    $csv_header .= 'Total Price'. ',';
                    $csv_header .= 'completed date'. ',';
                    $csv_header .= "\n";
                $csv_row ='';
                foreach ($post_id as $key => $item_data) {

                  $proData = $wpdb->get_results("SELECT * FROM `{$wpdb->prefix}woocommerce_order_items`WHERE `order_item_id` =  $item_data->order_item_id");
                  $proDataInfo = $wpdb->get_results("SELECT * FROM `{$wpdb->prefix}woocommerce_order_itemmeta`WHERE `order_item_id` =  $item_data->order_item_id " );
                  $proDataId = $wpdb->get_results("SELECT `meta_value` FROM `{$wpdb->prefix}woocommerce_order_itemmeta`WHERE `order_item_id` =  $item_data->order_item_id AND  `meta_key` ='_product_id'" );
                  $proDataQty = $wpdb->get_results("SELECT `meta_value` FROM `{$wpdb->prefix}woocommerce_order_itemmeta`WHERE `order_item_id` =  $item_data->order_item_id AND  `meta_key` ='_qty'" );
                  $proDataTotalAmount = $wpdb->get_results("SELECT `meta_value` FROM `{$wpdb->prefix}woocommerce_order_itemmeta`WHERE `order_item_id` =  $item_data->order_item_id AND  `meta_key` ='_line_total'" );


                      $order_id = $item_data->order_id;
                      $order_meta = get_post_meta($order_id);
                      $checkDate = explode(' ', $order_meta['_completed_date'][0])[0] ;
                      if(strtotime($intialDate) <= strtotime($checkDate) &&  strtotime($checkDate) <= strtotime($finalDate)){
                          $csv_row .= $order_meta['_shipping_first_name'][0].'-'.$order_meta['_billing_last_name'][0]. ',' ;
                          $csv_row .= $order_meta['_billing_email'][0]. ',' ;
                          $csv_row .= $order_meta['_billing_address_index'][0]. ',' ;
                          $csv_row .= $order_meta['_shipping_address_index'][0]. ',' ;
                          $csv_row .= $order_id. ',' ;
                          $csv_row .= $proDataId[0]->meta_value. ',' ;
                          $csv_row .= $proData[0]->order_item_name. ',' ;
                          $csv_row .= $proDataQty[0]->meta_value. ',' ;
                          $csv_row .= $proDataTotalAmount[0]->meta_value. ',' ;
                          $csv_row .= $order_meta['_completed_date'][0]. ',' ;
                          $csv_row .= "\n";  
                      }
                }
                header("Pragma: public");
                header("Expires: 0");
                header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
                header("Cache-Control: private", false);
                header("Content-Type: application/octet-stream");
                header("Content-Disposition: attachment; filename=\"report.csv\";" );
                header("Content-Transfer-Encoding: binary");
                echo $csv_header . $csv_row;exit;
          }
        // Add extra menu items for admins
        add_action('admin_menu', array($this, 'admin_menu'));
        // Create end-points
      add_filter('query_vars', array($this, 'query_vars'));
      add_action('parse_request', array($this, 'parse_request'));
    }
    /**
    * Add extra menu items for admins
    */
    public function admin_menu(){
      add_menu_page('Download Report', 'Download Report', 'manage_options', 'download_report', array($this, 'download_report'));
    }
    /**
    * Allow for custom query variables
    */
    public function csvexportFun(){
        $csv = $this->generate_csv();
        exit;
    }
    public function query_vars($query_vars){
      $query_vars[] = 'download_report';
      return $query_vars;
    }
    /**
    * Parse the request
    */
    public function parse_request(&$wp){
      if(array_key_exists('download_report', $wp->query_vars))
      {
      $this->download_report();
      exit;
      }
    }


    /**
    * Download report
    */
    public function download_report(){
         /* echo '<pre>';
         print_r( get_post_meta(28)) ;*/
          echo '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">';
          wp_enqueue_script( 'jquery-ui-datepicker' );
          // You need styling for the datepicker. For simplicity I've linked to Google's hosted jQuery UI CSS.
          wp_register_style( 'jquery-main', 'https://code.jquery.com/jquery-3.3.1.js' );
          wp_enqueue_style( 'jquery-main' );
          wp_register_style( 'jquery-dataTables', 'https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js' );
          wp_enqueue_style( 'jquery-dataTables' );  
          wp_register_style( 'jquery-databootstrap', 'https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js' );
          wp_enqueue_style( 'jquery-databootstrap' );  
          wp_register_style( 'jquery-ui', 'http://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css' );
          wp_enqueue_style( 'jquery-ui' ); 
          echo '<div class="wrap">';
          echo '<div id="icon-tools" class="icon32">
          </div>';
          echo '<h2>Download Report</h2>';
          echo '<script>
                  jQuery(document).ready(function($) {
                      $(".datepicker").datepicker({ dateFormat: "yy-mm-dd" });
                  });
              </script>';
               echo "<script>
                  jQuery(document).ready(function() {
                      jQuery('#example').DataTable();
                  } );
              </script>";
          global $wpdb;
           //echo $wpdb->prefix ;
           //echo "SELECT `order_id` FROM `{$wpdb->prefix}woocommerce_order_items` group By `order_id`" ; 
          $post_id = $wpdb->get_results("SELECT * FROM `{$wpdb->prefix}woocommerce_order_items` where  `order_item_type`='line_item'");
          
            $html1 = '<div class="container"><div class="row">';
            $html1 .= '<form   action="' . $_SERVER['REQUEST_URI'] . '"  method="post" id="nds_add_user_meta_form" >
                      <input type="submit"  name="download_report"  class="btn btn-success" value="Export All Data in CSV" >
                      </form></div>';
            $html1 .= '<div class="row" style=" margin-top: 13px;">
                        <form class="form-inline" role="form" method="post">
                       <div class="form-group">
                        <input type="name" class="form-control datepicker" name="intialDate"   placeholder="Intial Date">
                       </div>
                       <div class="form-group">
                        <input type="name" class="form-control datepicker" name="finalDate"   placeholder="Final Date">
                        </div>
                       <button type="submit" name="csvExportByData" class="btn btn-default">Export</button>
                    </form></div>' ;
            echo $html1 ;
            $html .= '<div class="row">
                    <table  id = "example" class="table table-condensed table-responsive" border="1" style="margin-top:20px;">
                      <tr>
                        <td><b>Customer Name</b></td>
                        <td><b>Customer Email</b></td>
                        <td><b>Customer Address</b></td>
                        <td><b>Shiping Address</b></td>
                        <td><b>#orderId</b></td>
                        <td><b>Product id</b></td>
                        <td><b>Product Name</b></td>
                        <td><b>Quantity</b></td>
                        <td><b>Total Price</b></td>
                        <td><b>completed date</b></td>
                      </tr>';
            foreach ($post_id as $key => $item_data) {
                  $proData = $wpdb->get_results("SELECT * FROM `{$wpdb->prefix}woocommerce_order_items`WHERE `order_item_id` =  $item_data->order_item_id");
                  $proDataInfo = $wpdb->get_results("SELECT * FROM `{$wpdb->prefix}woocommerce_order_itemmeta`WHERE `order_item_id` =  $item_data->order_item_id " );
                    echo '<pre>';
                    print_r($proDataInfo);die;
                  $proDataId = $wpdb->get_results("SELECT `meta_value` FROM `{$wpdb->prefix}woocommerce_order_itemmeta`WHERE `order_item_id` =  $item_data->order_item_id AND  `meta_key` ='_product_id'" );
                  $proDataQty = $wpdb->get_results("SELECT `meta_value` FROM `{$wpdb->prefix}woocommerce_order_itemmeta`WHERE `order_item_id` =  $item_data->order_item_id AND  `meta_key` ='_qty'" );
                  $proDataTotalAmount = $wpdb->get_results("SELECT `meta_value` FROM `{$wpdb->prefix}woocommerce_order_itemmeta`WHERE `order_item_id` =  $item_data->order_item_id AND  `meta_key` ='_line_total'" );
            $order_id = $item_data->order_id;
            $order = wc_get_order( $order_id );
            $order_meta = get_post_meta($order_id);
              $html .='<tr>
                          <td>'.$order_meta['_shipping_first_name'][0].'-'.$order_meta['_billing_last_name'][0].'</td>
                          <td>'.$order_meta['_billing_email'][0].'</td>
                          <td>'.$order_meta['_billing_address_index'][0].'</td>
                          <td>'.$order_meta['_shipping_address_index'][0].'</td>
                          <td>'.$order_id.'</td>
                          <td>'.$proDataId[0]->meta_value.'</td>
                          <td>'.$proData[0]->order_item_name.'</td>
                          <td>'.$proDataQty[0]->meta_value.'</td>
                          <td>'.$proDataTotalAmount[0]->meta_value.'</td>
                          <td>'.$order_meta['_completed_date'][0].'</td>
                        </tr>';
            }
            $csv_row .= "\n";
            $html .= '</table></div></div>';
            echo  $html ;
    }
    /**
    * Converting data to CSV
    */
    public function generate_csv(){
            global $wpdb;
          $post_id = $wpdb->get_results("SELECT * FROM `{$wpdb->prefix}woocommerce_order_items` where  `order_item_type`='line_item'");
            $csv_header = '';
            $csv_header .= 'Customer Name'. ',';
            $csv_header .= 'Customer Email'. ',';
            $csv_header .= 'Customer Address'. ',';
            $csv_header .= 'Shiping Address'. ',';
            $csv_header .= '#Order Id'. ',';
            $csv_header .= 'Product id'. ',';
            $csv_header .= 'Product Name'. ',';
            $csv_header .= 'Quantity'. ',';
            $csv_header .= 'Total Price'. ',';
            $csv_header .= 'completed date'. ',';
            $csv_header .= "\n";
            $csv_row ='';
            foreach ($post_id as $key => $item_data) {
                  $proData = $wpdb->get_results("SELECT * FROM `{$wpdb->prefix}woocommerce_order_items`WHERE `order_item_id` =  $item_data->order_item_id");
                  $proDataInfo = $wpdb->get_results("SELECT * FROM `{$wpdb->prefix}woocommerce_order_itemmeta`WHERE `order_item_id` =  $item_data->order_item_id " );
                  $proDataId = $wpdb->get_results("SELECT `meta_value` FROM `{$wpdb->prefix}woocommerce_order_itemmeta`WHERE `order_item_id` =  $item_data->order_item_id AND  `meta_key` ='_product_id'" );
                  $proDataQty = $wpdb->get_results("SELECT `meta_value` FROM `{$wpdb->prefix}woocommerce_order_itemmeta`WHERE `order_item_id` =  $item_data->order_item_id AND  `meta_key` ='_qty'" );
                  $proDataTotalAmount = $wpdb->get_results("SELECT `meta_value` FROM `{$wpdb->prefix}woocommerce_order_itemmeta`WHERE `order_item_id` =  $item_data->order_item_id AND  `meta_key` ='_line_total'" );
            $order_id = $item_data->order_id;
            $order_meta = get_post_meta($order_id);
                    $csv_row .= $order_meta['_shipping_first_name'][0].'-'.$order_meta['_billing_last_name'][0]. ',' ;
                    $csv_row .= $order_meta['_billing_email'][0]. ',' ;
                    $csv_row .= $order_meta['_billing_address_index'][0]. ',' ;
                    $csv_row .= $order_meta['_shipping_address_index'][0]. ',' ;
                    $csv_row .= $order_id. ',' ;
                    $csv_row .= $proDataId[0]->meta_value. ',' ;
                    $csv_row .= $proData[0]->order_item_name. ',' ;
                    $csv_row .= $proDataQty[0]->meta_value. ',' ;
                    $csv_row .= $proDataTotalAmount[0]->meta_value. ',' ;
                    $csv_row .= $order_meta['_completed_date'][0]. ',' ;
                    $csv_row .= "\n";  
                 }
            return $csv_header . $csv_row;
    }
}

// Instantiate a singleton of this plugin
$csvExport = new CSVExport();