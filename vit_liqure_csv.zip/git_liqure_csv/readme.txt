﻿=== Custom Posts For Product ===
Contributors: milindpd
Tags: custom,posts,product,category,price
Requires at least: 3.0.1
Tested up to: 4.9
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Builds custom posts for different product with thumbnails,price,tags,featured image under different categories.

== Description ==

This plugin builds Multiple custom posts for different product with thumbnails,price,tags,featured image under different categories.It is useful for small business those want to display their own products with categories, prices as they can set.



== Installation ==

ADMIN INSTALLER VIA SEARCH
1.Visit the Add New plugin screen and search for "Custom Posts For Product".
2.Click the "Install Now" button.
3.Activate the plugin.
4.Navigate to the "My Product" Menu.

ADMIN INSTALLER VIA ZIP
1.Visit the Add New plugin screen and click the "Upload Plugin" button.
2.Click the "Browse…" button and select zip file from your computer.
3.Click “Install Now” button.
4.Once done uploading, activate custom-posts-for-product.

MANUAL
1.Upload the "Custom Posts For Product" folder to the plugins directory in your WordPress installation.
2.Activate the plugin.
3.Navigate to the "My Product" Menu.

That’s it! Now you can easily start creating custom post types for product.


== Frequently Asked Questions ==


== Screenshots ==

1. The admin panel accepts custom posts for different categories as per requirement to customize page title and page contents.

== Changelog ==

Initial release