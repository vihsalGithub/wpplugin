<?php
require_once("../../../wp-load.php");
global $wpdb;   

$postData = get_post($_REQUEST['postid']);
$postMetaData = get_post_meta($_REQUEST['postid']);


$post_title = $postData->post_title;

$product_price = $postMetaData['product_price'][0];

$table_user_reg = $wpdb->prefix . "product_orders"; 
$userId = get_current_user_id() ;
$sql = "SELECT * FROM `".$table_user_reg."` WHERE  `product_id` = ".$_REQUEST['postid'];

$orderDetail = $wpdb->get_results($sql) ;


$csvDataArray = array();
foreach ($orderDetail as $key => $value) {
	$csvDataArray[$key]['post_title'] = $post_title;
	$csvDataArray[$key]['product_price'] = $product_price;
	$csvDataArray[$key]['person_name'] = $value->person_name;
	$csvDataArray[$key]['quantity'] = $value->quantity;
	$csvDataArray[$key]['delivery_dates'] = $value->delivery_dates;
	$csvDataArray[$key]['email'] = get_userdata($value->user_id)->user_email;
}



$csvColArray = array('Post title','Product price','Person name','Quantity','Delivery date','Email') ;

$csv_header = '';
   for ($i=0;$i<count($csvColArray);$i++) {
   	    $csv_header .= '"' . $csvColArray[$i] . '",';;
   }
$csv_header .= "\n";


if(count($csvDataArray)>0){
	foreach ($csvDataArray as $key => $value) {
		$csv_row .= '"' . $value['post_title'] . '",';
		$csv_row .= '"' . $value['product_price'] . '",';
		$csv_row .= '"' . $value['person_name'] . '",';
		$csv_row .= '"' . $value['quantity'] . '",';
		$csv_row .= '"' . $value['delivery_dates'] . '",';
		$csv_row .= '"' . $value['email'] . '",';
		$csv_row .= "\n";
	}
	
}


$file_name = $post_title.'_'.date('Y-m-d').'.csv';
$heaserFileName = 'Content-Disposition: attachment; filename='.$file_name ;
/* Download as CSV File */
header('Content-type: application/csv');
header($heaserFileName);
echo $csv_header . $csv_row;
exit;
            ?>
