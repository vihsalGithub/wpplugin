<?php
/*
Plugin Name: VIT post filter
Plugin URI: http://vitwebdevelopment.com/
Description: This is post filter plugin according to cat id 'Shortcode = [psot_filter_catid catID="2"  ]'
Author: VIT Category post
Version: 1.7.1
*/





function getUserEmail_func($atts) {
  	$html = '';
  	//$html .= $atts['userid'];
  	$html .= '<style>
.td-block-row{width:100%}.td-block-row .td-block-span6:first-child{width:340px;padding-right:20px}.td_block_1 .td_module_4{margin-bottom:0}.td-module-image{position:relative}.td-block-row{width:100%}.td-module-thumb{position:relative;margin-bottom:12px}@media (min-width:1024px){.td_module_4 .entry-thumb{min-height:194px}.td_module_6 .entry-thumb{min-height:75px}}.entry-title{font-size:19px;font-weight:600;line-height:24px;margin:0 0 9px}.meta-info{font-family:open sans,arial,sans-serif;font-size:11px;color:#444}.td-excerpt{margin-bottom:15px;color:#444;font-size:12px;line-height:18px}.td-block-row [class*=td-block-span]{display:block;min-height:1px;float:left}.td-block-span6{width:339px;padding-left:20px;padding-right:19px}.td_module_wrap{position:relative;z-index:0}.td_module_6 .td-module-thumb{position:absolute}.td-module-thumb{margin-bottom:12px}.td_module_6 .item-details{margin-left:115px;margin-bottom:20px;min-height:76px}.td_module_6 .entry-title{font-size:13px;font-weight:600;line-height:18px;margin:0 0 7px}.td_module_6 .meta-info{margin-bottom:0;line-height:11px}.td_module_6 .td-post-date{margin-top:3px;margin-bottom:3px;vertical-align:middle}.td-post-date{display:inline-block;margin-right:3px}.td_uid_20_5cb4c4722c0af_rand .td_module_wrap .td-post-category:hover{background-color:#ef9337}.td-module-thumb img{width:100%}.td-module-image .td-post-category{position:absolute;border-radius:0 3px 0 0;bottom:0;display:block}.td-post-category{font-family:open sans,arial,sans-serif;padding:2px 5px 3px;background-color:#222;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px;font-size:10px;font-weight:600;font-style:normal;color:#fff;margin-right:5px;position:relative;display:inline-block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%;vertical-align:middle;line-height:1}.td-module-comments a{color:#fff;padding:2px 4px 3px;display:inline-block;min-width:22px;height:20px;line-height:16px}.td-newsmag-magazine .td-module-comments{background-color:#222;border-radius:3px}.td-module-comments{position:relative;top:-3px;background-color:#848484;float:right;font-family:open sans,arial,sans-serif;font-size:11px;text-align:center}
</style>';


$catID = $atts['catid'] ;




$exist = term_exists($catID);

/*if($exist){
	$catID =  $catID ;
}else{
	$catID =  1 ;
}*/
//$data  = get_categories(2); 
//$data  = get_category($catID); 

$html .= '<div id="td_uid_20_5cb4c4722c0af" class="td_block_inner">
<div class="td-block-row">';

  $the_query = new  WP_Query( 
      array(
          'cat' => $catID,
          'posts_per_page' => 1,
      )
  ); 

   $the_query2 = new  WP_Query( 
      array(
          'cat' => $catID,
          'posts_per_page' => 4,
      )
  ); 
	while ( $the_query->have_posts() ) : $the_query->the_post(); 
	$html .='<div class="td-block-span6">
		<div class="td_module_4 td_module_wrap td-animation-stack">
			<div class="td-module-image">
				<div class="td-module-thumb">
					<a href="'.get_permalink().'" rel="bookmark" class="td-image-wrap" title="Plan Check: Modern American Cuisine">
						<img class="entry-thumb td-animation-stack-type0-2" src="'.get_the_post_thumbnail_url().'" alt="" title="'.get_the_title().'" data-type="image_tag" data-img-url="'.get_the_post_thumbnail_url().'" width="300" height="194">
					</a>
				</div> 
				<a href="https://demo.tagdiv.com/newsmag_magazine/category/lifestyle/dining/" class="td-post-category">'.get_cat_name($catID).'</a> 
			</div>
			<h3 class="entry-title td-module-title"><a href="'.get_permalink().'" rel="bookmark" title="Plan Check: Modern American Cuisine">'.get_the_title().'</a></h3>
			<div class="meta-info">
				<span class="td-post-author-name"><a href="'.get_the_author_link().'">'.get_author_name().'</a> <span>-</span> 
				</span> 
				<span class="td-post-date">
					<time class="entry-date td-module-date" datetime="2017-06-14T08:42:54+00:00">'.get_the_date() .'</time>
				</span> 
				<div class="td-module-comments">
					<a href="#">0</a>
				</div> 
			</div>
			<div class="td-excerpt">Whats possible in a week? If you dedicated seven days to the achievement of one goal, how ambitious could you make this goal? These... 
			</div>
		</div>
	</div>';
	endwhile;  
	while ( $the_query2->have_posts() ) : $the_query2->the_post(); 
	$html .= '<div class="td-block-span6">
		<div class="td_module_6 td_module_wrap td-animation-stack">
			<div class="td-module-thumb">
				<a href="'.get_permalink().'" rel="bookmark" class="td-image-wrap" title="The Best Dining in the Hamptons">
					<img style="width: 100px;" class="entry-thumb td-animation-stack-type0-2" src="'.get_the_post_thumbnail_url().'" alt="" title="'.get_the_title().'" data-type="image_tag" data-img-url="'.get_the_post_thumbnail_url().'">
				</a>
			</div>
			<div class="item-details">
			<h3 class="entry-title td-module-title"><a href="'.get_permalink().'" rel="bookmark" title="'.get_the_title().'">'.get_the_title().'</a></h3> 
			<div class="meta-info">
			<a href="'.get_permalink().'" class="td-post-category">'.get_cat_name($catID).'</a> <span class="td-post-date"><time class="entry-date  td-module-date" >'.get_the_date() .'</time></span> </div>
			</div>
		</div>
	</div> ';
	endwhile;  
$html .='</div>
</div>';
	

	return  $html;
}
add_shortcode('psot_filter_catid', 'getUserEmail_func');