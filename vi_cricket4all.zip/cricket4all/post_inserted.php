<?php
global $wpdb;

	if($_GET['select_url'] ==1){
		$url = "http://www.espncricinfo.com/rss/content/story/feeds/0.xml";
	}elseif($_GET['select_url'] ==2){
		$url = "http://static.cricinfo.com/rss/livescores.xml";
	}elseif($_GET['select_url'] ==3){
		$url = "http://www.espncricinfo.com/rss/content/story/feeds/6.xml";
	}else{
		//$url = "http://www.espncricinfo.com/rss/content/story/feeds/6.xml";
		echo "Please Select Any Url";
		die;
	}


	$post_cat = $_GET['select_category'] ;
	$handle = curl_init();
	//$url = "https://www.bhaskar.com/rss-feed/1053/";
	//$url = "http://www.espncricinfo.com/rss/content/story/feeds/6.xml";
	//$url = "https://www.news18.com/rss/cricketnext.xml";
	//$url = "http://www.espncricinfo.com/rss/content/story/feeds/0.xml";
	 
	// Set the url
	curl_setopt($handle, CURLOPT_URL, $url);
	// Set the result output to be a string.
	curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
	 
	$output = curl_exec($handle);

	$xml = simplexml_load_string($output); 
	$json = json_encode($xml); // convert the XML string to JSON
	$array = json_decode($json,TRUE); // convert the JSON-encoded string to a PHP variable
	 
	curl_close($handle);


	$todayDate = date('Y-m-d') ;
	 $date = $array['channel']['item'][0]['pubDate'] ;
	 $dateArray = explode(' ', $date);
	 // echo $dateArray[3].'-'.$dateArray[2].'-'.$dateArray[1];
	 //$date1 = 'July 25 2010';
	 $date1 = $dateArray[2].' '.$dateArray[1].' '.$dateArray[3];
	$newsDate = date('Y-m-d', strtotime($date1));

	if($todayDate == $newsDate){
	 if(!empty($array['channel']['item'])){
	 	$data = $array['channel']['item'] ;
	 	 foreach ($data as $key => $value) {
	 	   //echo	$value['coverImages'] ;

	 	 	$postTitle = $value['title'];
		    $query = "SELECT * FROM `{$wpdb->prefix}posts` WHERE `post_title` LIKE '{$postTitle}'";
		    $registerData = $wpdb->get_results($query);
		 	if($wpdb->num_rows){
		 		continue ;
		 	}

	 	 	if($key ==1){
	 	 		break ;
	 	 	}
	 	   $new_post = array(
			'post_title' => $value['title'],
			'post_content' => $value['description'] ,
			'post_status' => 'publish',
			'post_date' => date('Y-m-d H:i:s'),
			'post_author' => 1,
			'post_type' => 'post',
			'post_category' => array($post_cat)
			);
	 	   $post_id  = wp_insert_post($new_post);
	 	    /**************************/
		    $image_url        = $value['coverImages']; 
		    $image_name       = 'wp-header-logo.png';
		    $upload_dir       = wp_upload_dir(); 
		    $image_data       = file_get_contents($image_url); 
		    $unique_file_name = wp_unique_filename( $upload_dir['path'], $image_name );
		    $filename         = basename( $unique_file_name ); 
		    if( wp_mkdir_p( $upload_dir['path'] ) ) {
		        $file = $upload_dir['path'] . '/' . $filename;
		    } else {
		        $file = $upload_dir['basedir'] . '/' . $filename;
		    }
		    file_put_contents( $file, $image_data );
		    $wp_filetype = wp_check_filetype( $filename, null );
		    $attachment = array(
		        'post_mime_type' => $wp_filetype['type'],
		        'post_title'     => sanitize_file_name( $filename ),
		        'post_content'   => '',
		        'post_status'    => 'inherit'
		    );
		    $attach_id = wp_insert_attachment( $attachment, $file, $post_id );
		    require_once(ABSPATH . 'wp-admin/includes/image.php');
		    $attach_data = wp_generate_attachment_metadata( $attach_id, $file );
		    wp_update_attachment_metadata( $attach_id, $attach_data );
		    set_post_thumbnail( $post_id, $attach_id );

		    add_post_meta($post_id, 'post_url_link', $value['link']);
	 	    /**************************/

	 	    }
	    }
	}