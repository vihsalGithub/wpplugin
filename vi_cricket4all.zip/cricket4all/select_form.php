<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<style type="text/css">
			.formStyle{
				text-align: left;
			}
			.error{
				color: red;
			}
	 #responceMessage{
		 background-color: #ccc;
    padding: 10px 0px;
    margin-top: 10px;
	 }
		</style>

<?php
global $wpdb;


$args = array(
    'child_of'            => 0,
    'current_category'    => 0,
    'depth'               => 0,
    'echo'                => 1,
    'exclude'             => '',
    'exclude_tree'        => '',
    'feed'                => '',
    'feed_image'          => '',
    'feed_type'           => '',
    'hide_empty'          => 0,
    'hide_title_if_empty' => false,
    'hierarchical'        => true,
    'order'               => 'ASC',
    'orderby'             => 'name',
    'separator'           => '<br />',
    'show_count'          => 0,
    'show_option_all'     => '',
    'show_option_none'    => __( 'No categories' ),
    'style'               => 'list',
    'taxonomy'            => 'category',
    'title_li'            => __( 'Categories' ),
    'use_desc_for_title'  => 1,
);

//var_dump( wp_list_categories($args) );
//print_r(wp_list_categories($args));
$categories = get_categories($args);
//print_r($categories);

$html='<div class="container" style="margin-top:50px;">
	<div class="col-md-12">
<form class="form-horizontal" name="wessupTrackForm" id="wessupTrackForm" method="get" role="form">
                
                <div class="form-group">
				  <label for="sel1">Select list:</label>
				  <select class="form-control" id="select_url" name="select_url" required>
				  	<option>Select Url</option>
				    <option value= "1">Global news feed</option>
				    <option value= "2">Live matches</option>
				    <option value= "3">India</option>
				  </select>
				</div>
				<div class="form-group">
				  <label for="sel1">Select Category:</label>
				  <select class="form-control" id="select_category" name="select_category" required>
				  	<option>Select Category</option>';
					foreach($categories as $category) {
				   		 $html .='<option value= "'. $category->cat_ID.'">'.$category->name.'</option>';
				  	}
				  $html .='</select>
				</div>
                <input type="hidden"  name="message"  value="1">
                <input type="hidden"  name="page"  value="extra-post-info">
                <button style="width:146px;margin-left: 15px;" type="submit" id="getStatusBtn" class="btn btn-primary btn-block">Get Status</button>
            </form> <!-- /form -->';
   $html.='<div id="responceMessage"></div>';
   $html.='<div id="tokenId"></div>';
   $html.='<script>var plugin_url_chat = "'.plugins_url( 'ajax/userajax.php',__FILE__).'" </script>';
   $html.='</div></div>';
   ?>


