<?php

/*
Plugin Name: cricket4all plugin
Plugin URI: cricket4all.com
Author: vit
Version: 1.1
*/

define('VIT_VERSION','1.3.1');
define('VIT_VALID_UPDATE_I','2.9.1');
define('VIT_PATH',			dirname(__FILE__));
define('VIT_APP_PATH',		VIT_PATH.'/app');
define('VIT_PLUGIN_URL',	plugin_dir_url(__FILE__));
define("VIT_INCLUDE",       plugins_url('includes',__FILE__));
define("VIT_DIR_PATH", plugin_dir_path(__FILE__));

add_action( 'admin_menu', 'extra_post_info_menu' );
function extra_post_info_menu(){
  $page_title = 'WordPress Extra Post Info';
  $menu_title = 'Post Inserted';
  $capability = 'manage_options';
  $menu_slug  = 'extra-post-info';
  $function   = 'extra_post_info_page';
  $icon_url   = 'dashicons-media-code';
  $position   = 4;
  add_menu_page( $page_title,$menu_title,$capability,$menu_slug,$function,$icon_url,$position);
}

function extra_post_info_page(){ 
	//echo "hello";
	//include('post_inserted.php');

	if($_GET['message'] == 1){
			include('post_inserted.php');
	}else{
		include('select_form.php');
		echo $html ;
	}
}

?>

