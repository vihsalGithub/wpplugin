

function editUserStatus(id,status_id){
	jQuery("#updateFormBtn").show();
	jQuery("#user_edit_id").val(id);
	jQuery("#myModalEditUser").modal('show');
	/*jQuery.ajax({
		type:"post",
        data: {message_type:1},
		url:admin_ajax_url,
		success:function(data){
			alert(data);
			console.log(data);
		}
	});*/
}

jQuery("#updateFormBtn").click(function(){
	//alert(admin_ajax_url);
	jQuery("#updateFormBtn").hide();
	jQuery.ajax({
		type:"post",
        data: jQuery("#userFromUpdate").serialize(),
		url:admin_ajax_url,
		success:function(data){
			var obj = JSON.parse(data);
			jQuery("#updateFormResMessage").text('');
			jQuery("#updateFormResMessage").append(obj.message);
			console.log(data);
			setTimeout(function() {jQuery('#myModalEditUser').modal('hide');location.reload();}, 2000);
		}
	});
})