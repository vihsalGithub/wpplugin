<?php
/*
Plugin Name: wessups user plugin
Plugin URI: wessups.com
Author: vit
Version: 1.1
*/


define('VIT_VERSION','1.3.1');
define('VIT_VALID_UPDATE_I','2.9.1');
define('VIT_PATH',			dirname(__FILE__));
define('VIT_APP_PATH',		VIT_PATH.'/app');
define('VIT_PLUGIN_URL',	plugin_dir_url(__FILE__));
define("VIT_INCLUDE",       plugins_url('includes',__FILE__));
define("VIT_DIR_PATH", plugin_dir_path(__FILE__));

add_action( 'admin_menu', 'extra_post_info_menu' );
function extra_post_info_menu(){
  $page_title = 'WordPress Extra Post Info';
  $menu_title = 'Wessups users';
  $capability = 'manage_options';
  $menu_slug  = 'extra-post-info';
  $function   = 'extra_post_info_page';
  $icon_url   = 'dashicons-media-code';
  $position   = 4;
  add_menu_page( $page_title,$menu_title,$capability,$menu_slug,$function,$icon_url,$position);
}

function extra_post_info_page(){ 

	$adminPageUrl = admin_url('admin.php?page=extra-post-info');
    echo '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">';
	echo '<style>#setting-error-tgmpa , .elementor-message{display: none;} .coloneegiht{border: 1px solid #ccc;padding: 30px;}</style>';
	echo '<h2>Register User Information</h2><div class="row" style="margin:20px 0px;">
           <a href="'.$adminPageUrl.'&status=1" type="button" class="btn btn-primary btn-sm">Registraion</a>
           <a href="'.$adminPageUrl.'" type="button" class="btn btn-primary btn-sm">All List</a>
        </div>';
	if($_GET['status'] ==1){
		include('registration.php');
	}else{
		include('admin/adminboard.php');
	}
	echo $html;

	echo '<div class="container">
	  			<p><b>Registraion form shortcode:[wessupsregistration]</b></p>
	  			<p><b>Track form shortcode:[track]</b></p>
	 	  </div>';
	 	  
}

function wessups_registration_func( $atts ) {
	include('registration.php');
	return $html;
}
add_shortcode( 'wessupsregistration', 'wessups_registration_func' );

function wessups_track_func( $atts ) {
	include('wessupstrack.php');
	return $html;
}
add_shortcode( 'track', 'wessups_track_func' );

function table_install() {
	  global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		include('database/database.php');

}
register_activation_hook( __FILE__, 'table_install' );









?>
