<!-- Latest compiled and minified CSS -->

<!-- Latest compiled and minified CSS -->
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
 --><style type="text/css">
			.formStyle{
				text-align: left;
			}
			.error{
				color: red;
			}
			.coloneegiht{border: 1px solid #ccc;padding: 30px;}
		</style>

<?php
global $wpdb;
wp_enqueue_style( 'customcss', plugins_url( 'assets/custom.css', __FILE__ ) );
wp_enqueue_script( 'customscript', plugins_url( 'assets/custom.js', __FILE__ ));
$registrationTbl = $wpdb->prefix . "vit_register_users";
$userStauts = $wpdb->prefix . "vit_register_user_status";
/*$sql = "SELECT * FROM `".$userStauts."` WHERE `read_status` = 1 ";
echo $sql ;
$dataValue = $wpdb->get_results($sql);*/
//print_r($dataValue);
/*foreach ($dataValue as $key => $value) {
	echo $value->user_status ;
}*/

$html ='<div class="container"><div class="col-md-8 coloneegiht">';

$html.='<form class="form-horizontal" name="wessupUserForm" id="wessupUserForm" method="post" role="form" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">First Name</label>
                    <div class="col-sm-9">
                        <input type="text" id="first_name"  name="first_name" placeholder="First Name" class="form-control" autofocus required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="lastName" class="col-sm-3 control-label">Last Name</label>
                    <div class="col-sm-9">
                        <input type="text" id="last_name"  name="last_name" placeholder="Last Name" class="form-control" autofocus  required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="birthDate" class="col-sm-3 control-label">Date of Birth*</label>
                    <div class="col-sm-9">
                        <input type="date" id="date_of_birth"  name="date_of_birth" class="form-control" required>
                    </div>
                </div>

                 <div class="form-group">
                    <label class="control-label col-sm-3">Gender</label>
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input type="radio" name="gender" id="femaleRadio" value="Female" >Female
                                </label>
                            </div>
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input type="radio"  name="gender"  id="maleRadio" value="Male" >Male
                                </label>
                            </div>
                        </div>
                    </div>
                </div> <!-- /.form-group -->

                <div class="form-group">
                    <label for="phoneNumber" class="col-sm-3 control-label">Contact number </label>
                    <div class="col-sm-9">
                        <input type="contactNo" id="contact_number" name="contact_number" placeholder="Contact number" class="form-control"  >
                    </div>
                </div>

                <div class="form-group">
                    <label for="address" class="col-sm-3 control-label">Address</label>
                    <div class="col-sm-9">
                        <input type="text" id="user_address" name="user_address" placeholder="Address" class="form-control" >
                    </div>
                </div>
                <div class="form-group">
                    <label for="user_email" class="col-sm-3 control-label">User Email</label>
                    <div class="col-sm-9">
                        <input type="email" id="user_email" name="user_email" placeholder="User Email" class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <label for="track_id" class="col-sm-3 control-label">#Track id</label>
                    <div class="col-sm-9">
                        <input type="text" id="track_id" name="track_id" placeholder="User Email" class="form-control" value="'.rand ( 10000 , 99999 ).'" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="visa_docs_file" class="col-sm-3 control-label">Visa Docs File</label>
                    <div class="col-sm-9">
                        <input type="file" id="visa_docs_file" name="visa_docs_file" placeholder="User Email" class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <label for="visa_docs_file" class="col-sm-3 control-label">Fee Receipt File</label>
                    <div class="col-sm-9">
                        <input type="file" id="fee_rec_file" name="fee_rec_file" placeholder="User Email" class="form-control">
                    </div>
                </div>
                
                <input type="hidden" id="registration_time" name="registration_time" value="'.time().'">
                <input type="hidden" id="registration_date" name="registration_date" value="'.date("Y-m-d").'" >
                <input type="hidden" id="course_name" name="course_name" value="none">
                <input type="hidden" id="user_status" name="user_status"  value="1">
                <input type="hidden" id="message_type" name="message_type"  value="1">

                <button type="submit" class="btn btn-primary btn-block">Register</button>
            </form> <!-- /form -->';
   $html.='<div id="responceMessage"></div>';
   $html.='<div id="tokenId"></div>';
   $html.='<script>var plugin_url_chat = "'.plugins_url( 'ajax/userajax.php',__FILE__).'" </script>';
      $html .='</div></div>';

   ?>

<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script type="text/javascript">
jQuery(function(){
  /* data: jQuery("#wessupUserForm").serialize(),*/
  jQuery("form[name='wessupUserForm']").validate({
  	rules: {
	   first_name: "required",
	   last_name: "required",
	 },
	 messages: {
	  first_name: "Please enter your first name",
	  last_name: "Please enter your last name",
	 },

    submitHandler: function(form) {
      	var formValue = jQuery('#wessupUserForm')[0];
        var formdata = new FormData(formValue);
        jQuery.ajax({
            type:"post",
            url:plugin_url_chat,
            data: formdata,
            contentType: false,
            cache: false,
            processData:false,  
            enctype: 'multipart/form-data',     
          success:function(data){
            alert();
            console.log(data);
            var obj = JSON.parse(data);
              jQuery("#responceMessage").text('');
              jQuery("#tokenId").text('');
              jQuery("#responceMessage").append(obj.message);
              jQuery("#tokenId").append(obj.token_id);
          }
        });
    }
  });
});


   
    

</script>

