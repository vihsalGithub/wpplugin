<?php
/*chat table Create*/

   $table1 = $wpdb->prefix . 'vit_register_users';
          $usertblCreate = "CREATE TABLE `".$table1."` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `first_name` varchar(255) NOT NULL,
                            `last_name` varchar(255) NOT NULL,
                            `contact` varchar(255) NOT NULL,
                            `address` varchar(255) NOT NULL,
                            `user_email` varchar(255) NOT NULL,
                            `gender` int(11) DEFAULT NULL,
                            `course_name` varchar(255) NOT NULL,
                            `date_of_birth` varchar(255) NOT NULL,
                            `track_id` int(11) NOT NULL,
                            `time` int(11) NOT NULL,
                            `registration_date` varchar(255) NOT NULL,
                            `user_status` int(11) NOT NULL DEFAULT '0'
                            , PRIMARY KEY (`id`)
                        ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
       dbDelta($usertblCreate); 






      $userstatusTableCreate = "CREATE TABLE `".$wpdb->prefix."vit_register_user_status` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `user_status` varchar(255) NOT NULL,
                            `read_status` int(11) NOT NULL DEFAULT '0'
                            , PRIMARY KEY (`id`)
                          ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
      dbDelta($userstatusTableCreate); 
      $userstatusTableCreateInsVal =  "INSERT INTO `".$wpdb->prefix."vit_register_user_status` (`id`, `user_status`, `read_status`) VALUES
            (1, 'Pending', 1),
            (2, 'Processing', 1),
            (3, 'On Hold', 1),
            (4, 'Completed', 1),
            (5, 'Cancelled', 1),
            (6, 'Failed', 1);" ;
      dbDelta($userstatusTableCreateInsVal); 
      
     


/*chat table Create End*/
?>