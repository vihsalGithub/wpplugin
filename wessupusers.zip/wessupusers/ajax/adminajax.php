<?php
include_once('../../../../wp-config.php');
include_once('../../../../wp-load.php');
include_once('../../../../wp-includes/wp-db.php');

global $wpdb;
$vit_register_users = $wpdb->prefix . "vit_register_users";

if($_POST['message_type']==1){
	echo "hello";
}
if($_POST['message_type']==2){
	//print_r($_POST);
	$updateSql = "UPDATE `".$vit_register_users."` SET `user_status` = '".$_POST["user_status_update"]."' WHERE  `id` = ".$_POST["edit_id"]; 
    $wpdb->query($updateSql) ;
    echo json_encode(array('status'=>true,'message'=>'<p class="text-success text-center">Updated Successfully</p>'));
}
