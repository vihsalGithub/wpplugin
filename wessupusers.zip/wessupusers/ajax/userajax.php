<?php
include_once('../../../../wp-config.php');
include_once('../../../../wp-load.php');
include_once('../../../../wp-includes/wp-db.php');

global $wpdb;
$table_user_reg = $wpdb->prefix . "vit_register_users"; 
$track_id = $_POST["track_id"];
 // echo $_POST['message_type']; die;
if($_POST['message_type']==1){
	$sql = "SELECT * FROM `".$table_user_reg."` WHERE `track_id` = ".$_POST["track_id"];
	/*$sql = "SELECT * FROM `".$table_user_reg."` WHERE `first_name` LIKE 'vish%' AND `date_of_birth` LIKE '1991-01-01'";*/
	//echo $sql ;die ;
	$dataValue = $wpdb->get_row($sql);
	if($dataValue){
		$jsonarray = array('staus'=>false,'message'=>'<p><h2 class="text-danger text-center" style="border:1px solid #000;font-size: 24px;margin-top:10px;padding:10px ">Track id already exist</h2></p>','token_id'=>"");
		echo json_encode($jsonarray) ;
	}else{
		$query = "INSERT INTO ".$table_user_reg." ( `first_name`,`last_name`,`contact`,`address`,`user_email`,`gender`,`course_name`,`date_of_birth`,`track_id`,`time`,`registration_date`,`user_status`) VALUES ( '".$_POST["first_name"]."','".$_POST["last_name"]."','".$_POST["contact_number"]."','".$_POST["user_address"]."','".$_POST["user_email"]."','".$_POST["gender"]."','".$_POST["course_name"]."','".$_POST["date_of_birth"]."','".$_POST["track_id"]."','".$_POST["registration_time"]."','".$_POST["registration_date"]."','".$_POST["user_status"]."');";
		$wpdb->query($query) ;
		$lastid = $wpdb->insert_id;
		 if($lastid){
		 	$token = '<p class="text-success text-center ">Your Token Id:<b>'.$track_id.'</b></p>' ;
		 	$jsonarray = array('staus'=>true,'message'=>'<h3 class="text-success text-center"style="font-size: 24px;margin-top:10px;padding:10px ">Successfully Register</h3>','token_id'=>$token);
		 	echo json_encode($jsonarray) ;
		 }else{
		 	$jsonarray = array('staus'=>false,'message'=>'Not Register','token_id'=>"");
		 	echo json_encode($jsonarray) ;
		 }
	}
}
if($_POST['message_type']==2){

	/*$sql = "SELECT *,(select `user_status` FROM `".$wpdb->prefix ."vit_register_user_status` where id = `ru`.`user_status` ) as user_status_Value  FROM `".$table_user_reg."` as ru WHERE  ( `contact`= ".$_POST["contact_number"]." OR `user_email`= ".$_POST["contact_number"]." )  AND `track_id` = ".$_POST["track_id"];*/
	$dob = $_POST["date_of_birth"] ;
	$dobarray = explode('-', $dob) ;
	$dobString = $dobarray[2].'-'.$dobarray[1].'-'.$dobarray[0];
	$sql = "SELECT *,(select `user_status` FROM `".$wpdb->prefix ."vit_register_user_status` where id = `ru`.`user_status` ) as user_status_Value  FROM `".$table_user_reg."` as ru WHERE  `date_of_birth` = '".$dob."'   AND `track_id` = ".$_POST["track_id"];
	//echo $sql ;die;
	$dataValue = $wpdb->get_row($sql);
	if($wpdb->num_rows>0){
		$string = '';
		$string .= 'Hello '.$dataValue->first_name.'-'.$dataValue->last_name.' <br>Your Status is:'.$dataValue->user_status_Value;
		$jsonarray = array('staus'=>true,'message'=>'<p><h2 class="text-center" style="border:1px solid #000;font-size: 24px;">'.$string.'</p>','token_id'=>$_POST["track_id"]);
		echo json_encode($jsonarray) ;
	}else{
		$jsonarray = array('staus'=>false,'message'=>'<p><h2 class="text-center" style="border:1px solid #000;font-size: 24px;">No Match</h4></p>','token_id'=>$_POST["track_id"]);
		echo json_encode($jsonarray) ;
	}
}

if($_POST['message_type']==3){
	//echo "delete";
	$delQuery = "DELETE FROM `".$table_user_reg."` WHERE `".$table_user_reg."`.`id` = ".$_POST['delID'] ;
	$wpdb->query($delQuery) ;
	//echo $delQuery ;
	echo json_encode(array('status'=>true,'message'=>"deleted")) ;

}

//print_r($_POST);