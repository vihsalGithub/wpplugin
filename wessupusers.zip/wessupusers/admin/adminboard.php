<!-- Latest compiled and minified CSS -->

<!-- Latest compiled and minified CSS -->

<style type="text/css">
			.formStyle{
				text-align: left;
			}
			.error{
				color: red;
			}

      #setting-error-tgmpa , .elementor-message{
        display: none;
      }
			
		</style>

<?php
global $wpdb;

wp_enqueue_style( 'customcss', VIT_PLUGIN_URL. 'assets/custom.css');
wp_enqueue_script( 'customscript',VIT_PLUGIN_URL. 'assets/custom.js');
$registrationTbl = $wpdb->prefix . "vit_register_users";
$userStauts = $wpdb->prefix . "vit_register_user_status";
$sql = "SELECT * FROM `".$userStauts."` WHERE `read_status` = 1 ";
$dataValue = $wpdb->get_results($sql);
/*foreach ($dataValue as $key => $value) {
	echo $value->user_status ;
}*/

$mainQuery = "SELECT *,(select `user_status` from ".$userStauts." where id= ru.`user_status`) as user_status_value FROM ".$registrationTbl." as ru  order by id desc";
$registerData = $wpdb->get_results($mainQuery);



$html='<div class="table-responsive">          
  <table class="table">
    <thead>
      <tr>
        <th>#</th>
        <th>Name</th>
        <th>Contact</th>
        <th>Registration Date</th>
        <th>DOB</th>
        <th>Status</th>
        <th>Track ID</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>';

foreach ($registerData as $key => $value) {
      $username  = $value->first_name.'-'.$value->last_name ;
     
      $html.='<tr>
        <td>'.($key+1).'</td>
        <td>'.$username.'</td>
        <td>'.$value->contact.'</td>
        <td>'.$value->registration_date.'</td>
        <td>'.$value->date_of_birth.'</td>
        <td>'.$value->user_status_value.'</td>
        <td>'.$value->track_id.'</td>
        <td>
            <button onclick="editUserStatus('.$value->id.','.$value->user_status.')" class="btn btn-info">Change Status</button>
            <button onclick="deleteUserStatus('.$value->id.')"  id="deleteFormBtn" type="button" class="btn btn-danger">Delete</button>
        </td>

      </tr>' ;
}

    $html.='</tbody>
  </table>
  </div>';
   $html.='<div id="responceMessage"></div>';
   $html.='<div id="tokenId"></div>';
   $html.='<!-- Modal -->
            <div id="myModalEditUser" class="modal fade" role="dialog">
              <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Modal Header</h4>
                  </div>
                  <div class="modal-body">
                      <div class="row">
                        <form name="userFromUpdate" id="userFromUpdate">
                        <div class="col-md-12">
                          <div class="form-group">
                            <label for="sel1">Select Status:</label>
                            <select class="form-control" name="user_status_update" id="user_status_update">';
                            foreach ($dataValue as $key => $value) {
                              $html.='<option value="'.$value->id.'">'.$value->user_status.'</option>';
                            }
                            $html.='</select>
                          </div>
                        </div>
                        <input type ="hidden" value="" name="edit_id" id="user_edit_id">
                        <input type ="hidden" value="2" name="message_type" id="message_type">
                          <div class="col-md-12" id="updateFormResMessage">
                          </div>
                          <div class="col-md-12">
                            <button  id="updateFormBtn" type="button" class=" btn-md btn btn-primary btn-sm btn-block">Update</button>

                          </div>
                        </form>
                      </div>
                      </div>
                  </div>
              </div>
            </div>';
   $html.='<script>var admin_ajax_url = "'.VIT_PLUGIN_URL.'ajax/adminajax.php'.'" </script>';
   $html.='<script>var admin_ajax_url_user = "'.VIT_PLUGIN_URL.'ajax/userajax.php'.'" </script>';

   $html.='<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>';


   ?>

<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script type="text/javascript">
/*jQuery(function(){
  jQuery("form[name='wessupUserForm']").validate({
    submitHandler: function(form) {
      	//form.submit();
      	jQuery.ajax({
            type:"post",
            data: jQuery("#wessupUserForm").serialize(),
            url:  plugin_url_chat,
      		success:function(data){
      			console.log(data);
      			var obj = JSON.parse(data);
      				jQuery("#responceMessage").text('');
      				jQuery("#tokenId").text('');
      				jQuery("#responceMessage").append(obj.message);
      				jQuery("#tokenId").append(obj.token_id);
      		}
      	});
    }
  });
});*/

function deleteUserStatus(id){
    var r = confirm("Do you want remove this entry");
      if (r == true) {
          jQuery.ajax({
            type:"post",
            data: {message_type:3,delID:id},
            url:  admin_ajax_url_user,
            success:function(data){
              console.log(data);
              location.reload();
            }
          });
      } 
  }
</script>

