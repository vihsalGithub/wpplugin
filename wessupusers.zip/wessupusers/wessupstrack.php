<!-- Latest compiled and minified CSS -->

<!-- Latest compiled and minified CSS -->
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
 --><style type="text/css">
			.formStyle{
				text-align: left;
			}
			.error{
				color: red;
			}
	 #responceMessage{
		 background-color: #ccc;
    padding: 10px 0px;
    margin-top: 10px;
	 }
		</style>

<?php
global $wpdb;
wp_enqueue_style( 'customcss', plugins_url( 'assets/custom.css', __FILE__ ) );
wp_enqueue_script( 'customscript', plugins_url( 'assets/custom.js', __FILE__ ));
$registrationTbl = $wpdb->prefix . "vit_register_users";
$userStauts = $wpdb->prefix . "vit_register_user_status";
/*$sql = "SELECT * FROM `".$userStauts."` WHERE `read_status` = 1 ";
echo $sql ;
$dataValue = $wpdb->get_results($sql);*/
//print_r($dataValue);
/*foreach ($dataValue as $key => $value) {
	echo $value->user_status ;
}*/


$html='<form class="form-horizontal" name="wessupTrackForm" id="wessupTrackForm" method="post" role="form">
                
                <!--<div class="form-group">
                    <label for="phoneNumber" class="col-sm-3 control-label">Contact/Email </label>
                    <div class="col-sm-9">
                        <input type="contactNo" id="contact_number" name="contact_number" placeholder="Contact number" class="form-control"  required>
                    </div>
                </div> -->

                <div class="form-group">
                    <label for="phoneNumber" class="col-sm-3 control-label">Date Of Birth</label>
                    <div class="col-sm-9">
                        <input type="date" id="date_of_birth" name="date_of_birth" placeholder="Contact number" class="form-control"  required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="phoneNumber" class="col-sm-3 control-label">Student Id number </label>
                    <div class="col-sm-9">
                        <input type="contactNo" id="track_id" name="track_id" placeholder="Student Id number" class="form-control"  required>
                    </div>
                </div>
				
				<div class="form-group">
                    <label for="phoneNumber" class="col-sm-3 control-label">Student Surname</label>
                    <div class="col-sm-9">
                        <input type="contactNo" id="surname" name="surname" placeholder="Student Surname" class="form-control"  required>
                    </div>
                </div>

                <input type="hidden" id="message_type" name="message_type"  value="2">
                <button style="width:146px;margin-left: 15px;" type="submit" id="getStatusBtn" class="btn btn-primary btn-block">Get Status</button>
				<p id="pleaseWait" class="text-center text-success">Please Wait.....</p>
            </form> <!-- /form -->';
   $html.='<div id="responceMessage"></div>';
   $html.='<div id="tokenId"></div>';
   $html.='<script>var plugin_url_chat = "'.plugins_url( 'ajax/userajax.php',__FILE__).'" </script>';
   ?>

<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script type="text/javascript">
jQuery(function(){
	jQuery("#pleaseWait").hide();
  jQuery("form[name='wessupTrackForm']").validate({
    submitHandler: function(form) {
      	//form.submit();
      	jQuery("#pleaseWait").show(); 
		jQuery("#getStatusBtn").show();
      	jQuery.ajax({
            type:"post",
            data: jQuery("#wessupTrackForm").serialize(),
            url:  plugin_url_chat,
      		success:function(data){
            //alert(data);
      			console.log(data);
				jQuery("#pleaseWait").hide();
      			var obj = JSON.parse(data);
      				jQuery("#responceMessage").text('');
      				jQuery("#tokenId").text('');
      				jQuery("#responceMessage").append(obj.message);
      				/*jQuery("#tokenId").append(obj.token_id);*/
      		}
      	});
    }
  });
});
</script>

