<?php _e( 'Hi,', 'dokan-store-support' ); ?>

<?php _e( 'A support request has been made by customer on your store ', 'dokan-store-support' ); ?>"[store-name]".

<?php _e( 'You can see it by going here :', 'dokan-store-support' ); ?> [support-dashboard]

---
<?php _e( 'From', 'dokan-store-support' ); ?> [site-name]
[site-url]