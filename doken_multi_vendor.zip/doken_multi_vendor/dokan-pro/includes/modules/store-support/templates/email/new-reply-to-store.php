<?php _e( 'Hello,', 'dokan-store-support' ); ?>

<?php _e( 'A new reply was made in the ticket ', 'dokan-store-support' ); ?>"[ticket-title]".

<?php _e( 'See the details by going here:', 'dokan-store-support' ); ?>
[dashboard-ticket-url]

---
<?php _e( 'From', 'dokan-store-support' ); ?> [site-name]
[site-url]