dokanWebpack([3],{

/***/ 159:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _hooks = __webpack_require__(15);

dokan.wpPackages = {
    hooks: (0, _hooks.createHooks)()
};

/***/ })

},[159]);