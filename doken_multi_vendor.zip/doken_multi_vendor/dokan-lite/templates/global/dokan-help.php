<?php
/**
 * Dokan Help Text Template
 *
 * @since 2.4
 *
 * @package dokan
 */
?>

<div class="dokan-page-help">
    <?php echo $help_text; ?>
</div>
