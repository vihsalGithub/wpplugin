<?php
wp_enqueue_style( 'custom', plugins_url( 'chat/custom.css',__FILE__) );
  	$themeUrl = '<style> #chatMsgForm{background-image:url("'.plugins_url( 'chat/images/chattheme.jpg',__FILE__).'") !important ;}</style>' ;
   	//echo $themeUrl ;
    if(is_admin()){
       // echo "login";
         $time = time() ;
         //echo $time ;
         $query = "UPDATE `{$wpdb->prefix}vit_admin_login_status` SET 
        `admin_status`= 1, 
        `chat_time`= $time 
        WHERE  `{$wpdb->prefix}vit_admin_login_status`.`id` =1";
          //echo $query ;
          $wpdb->query($query);
    }
    /*chat box Setting*/
    $vit_chatbox_setting = $wpdb->prefix . "vit_chatbox_setting";
    $chatSettSql = "SELECT * FROM `".$vit_chatbox_setting."` WHERE `id` = 1";
    $chatSettData = $wpdb->get_row($chatSettSql);
    //print_r($chatSettData);
    echo '<style>
    .msjAdmin {background: #'.$chatSettData->chat_textAreaColor.' !important;}
    .msj {background: #'.$chatSettData->chat_textAreaColor.' !important;}
    .msj-rta {background: #'.$chatSettData->chat_textAreaColor.' !important;}
    .msj-rta::after{border-color:#'.$chatSettData->chat_textAreaColor.' whitesmoke #'.$chatSettData->chat_textAreaColor.'transparent #'.$chatSettData->chat_textAreaColor.' transparent #'.$chatSettData->chat_textAreaColor.' transparent  !important;}
    .msj::before{border-right-color: #'.$chatSettData->chat_textAreaColor.' !important;}
    .msj-rta::after{ border-top-color: #'.$chatSettData->chat_textAreaColor.'  !important;}
    .text > p:last-of-typ{color:  #'.$chatSettData->chat_textColor.'  !important;}
     #chatMsgForm p{color:  #'.$chatSettData->chat_textColor.'  !important;}
    .chat-popup{border: 2px solid #'.$chatSettData->chat_boxBorderColor.' !important;}
    #chatMsgForm{background:#'.$chatSettData->chat_mainBgColor.' !important;}
    #chatMsgForm h1{background-color: #'.$chatSettData->chat_textAreaColor.'!important;color: #'.$chatSettData->chat_textColor.';}
    #backBtnAdmin{color: #'.$chatSettData->chat_backTextColor.'!important;}
    .open-button{background-color: #'.$chatSettData->chat_mainBgColor.'!important;color: #'.$chatSettData->chat_textColor.'  !important;}
    </style>';
    /*chat box Setting*/


 	$table_name_chat = $wpdb->prefix . "vit_chat_messages";
    $sql = "SELECT `member_id` FROM `".$table_name_chat."` GROUP BY `member_id` ORDER BY `id` DESC";
    $chatMemeberIdData = $wpdb->get_results($sql);
        $javascript = '<button class="open-button" onclick="openForm()">Chat</button>
              <div class="chat-popup" id="myForm"><div id="formAdmin" >
              <form  id="chatMsgForm" class="form-container" method="post" >
                 <p class="curPointer" style="color: #fff;font-weight:bold" id="backBtnAdmin">Back</p>
                <h1 id="selctUserName" style="margin-top: 0px;border: none;">All Members Messages</h1><div id="mainContainer" >';
                //$javascript .='<script>setInterval(function(){console.log("hello")}, 5000)</script>';
                $javascript .='<div class="mainBodyDiv"><script>var myVarInterval =  setInterval(function(){adminGroupByMessage()}, 5000)</script></div>';
                $javascript .='<ul id="mainContainerUl">';
                    foreach ($chatMemeberIdData as $key => $value) {
		        		

                /*$sql2 = "SELECT `id`,`webinar_id`,`name`,`email`,`webinar_type`, (SELECT `name` FROM `".$wpdb->prefix."vit_chat_users` WHERE `id` = `webinar_id` ) as webinar_name    FROM `".$wpdb->prefix."vit_webinar_members` as  swm  WHERE `id` =".$value->member_id ;*/
                $sql2 = "SELECT * FROM `".$wpdb->prefix."vit_chat_users` as  swm  WHERE `id` =".$value->member_id ;
	    				$memberChatData = $wpdb->get_row($sql2);
	    				$query2 = "SELECT count(*) as totalRow FROM `".$table_name_chat."` WHERE admin_read_status = 0 AND member_id =".$value->member_id ;
	    				$unreadMessage = $wpdb->get_row($query2);
	    				    $_SESSION['chat_user_id'] = $memberChatData->id ;
	    				   //print_r($memberChatData);admin_read_status
	    				 $javascript .='<li style="width:100%">
	    				 					<span class="curPointer"  onclick="allMessage('.$memberChatData->id.')">
				                            <div class="msjAdmin macro ">
				                               <div class="textAdmin text text-l">
				                                   <p style="font-weight: bold;">'.$memberChatData->name.'</p>
				                                   <p class="webNamePara">
				                                   <small>'.$memberChatData->name.'</samll>
				                                   <span class="unreadMessage1">'.$unreadMessage->totalRow.'</span>
				                                   </p>
				                               </div>
				                            </div>
				                            </span>
				                        </li>';
		        		}
                $javascript .='</ul>';
                $javascript .='</div><div class="chatText">
                    <input type="text"   class="inputfield submitMsgAdmin" placeholder="Type message.."    id="messageInput" name="message" required / >
                     <input type="hidden" placeholder="member_id" id="member_id" name="member_id" value="'.$memberChatData->id.'" / >
                     <input type="hidden" placeholder="userid" name="messageStatus" id="messageStatus" value="1" / >
                     <input type="hidden" placeholder="token_id" name="token_id"  id="token_id" value="12345" / >
                     <input type="hidden" placeholder="msg_conservation" name="msg_conservation" id="msg_conservation" value="1" / >
                    </div>
                    <button type="button" name="submitMessage"  id="submitBtnAdmin" class="submitMessage btnClass btnSend"  style="background:#'.$chatSettData->chat_sendBtnColor.'">Send</button>
                    <button type="button" id="closeBtnAdmin" class="submitMessage btnClass btnClose" onclick="closeForm()" style="background:#'.$chatSettData->chat_closeBtnColor.'">Close</button>
                    <div></form>
                </div>';
    	wp_enqueue_script( 'custom-script1', plugins_url( 'chat/custom.js',__FILE__));
        $javascript.='<div class="reLoadScriptAdmin"></div>';
        $javascript.='<script>var plugin_url_chat = "'.plugins_url( 'chat/ajax.php',__FILE__).'" </script>';
        $javascript.='<script>var plugin_url_chat_admin = "'.plugins_url( 'chat/ajaxAdmin.php',__FILE__).'" </script>';

    	echo $javascript ;