<?php


include_once('../../../../wp-config.php');
include_once('../../../../wp-load.php');
include_once('../../../../wp-includes/wp-db.php');


global $wpdb;
$table_name_chat = $wpdb->prefix . "vit_chat_messages";
if($_POST["conditionType"]==1){
  $sql = "SELECT * FROM `".$table_name_chat."` WHERE `member_id` = ".$_POST["member_id"];
  $chatData = $wpdb->get_results($sql) ;
      $html = '';
    foreach ($chatData as $key => $value) {
            if($value->msg_conservation ==1){
              $htmlClass = 'msj-rta macro';
            }else{
              $htmlClass = 'msj  macro';
            }
             $html .='<li style="width:100%">
                      <div class="'.$htmlClass.'">
                         <div class="text text-l">
                             <p>'.$value->message.'</p>
                             <p><small>'.$value->msg_time.'</small>
                             </p>
                         </div>
                      </div>
                  </li>';
            }
    echo $html;
    
    
    $updateSql = "UPDATE `".$table_name_chat."` SET `admin_read_status` = '1' WHERE `admin_read_status` = 0 AND `member_id` = ".$_POST["member_id"]; 
    $wpdb->query($updateSql) ;
    
    
    
    
}elseif($_POST["conditionType"]==2){
    $sql = "SELECT `member_id` FROM `".$table_name_chat."` GROUP BY `member_id` ORDER BY `id` DESC";
    $chatMemeberIdData = $wpdb->get_results($sql);
     
     //  print_r($chatMemeberIdData);   

    $chatData = $wpdb->get_results($sql);
          foreach ($chatMemeberIdData as $key => $value) {
              
             // echo $value->member_id ;
          $sql2 = "SELECT `id`,`webinar_id`,`name`,`email`,`webinar_type`, (SELECT `name` FROM `".$wpdb->prefix."vit_webinars` WHERE `id` = `webinar_id` ) as webinar_name    FROM `".$wpdb->prefix."vit_webinar_members` as  swm  WHERE `id` =".$value->member_id ;
          $memberChatData = $wpdb->get_row($sql2);
          	$query2 = "SELECT count(*) as totalRow FROM `".$table_name_chat."` WHERE admin_read_status = 0 AND member_id =".$value->member_id ;
	    				$unreadMessage = $wpdb->get_row($query2);
            $htmlData2 .='<li style="width:100%" id="dsanndsanas">
                          <span style="cursor:pointer" onclick="allMessage('.$memberChatData->id.')">
                              <div class="msjAdmin macro ">
                                 <div class="textAdmin text text-l">
                                     <p style="font-weight: bold;">'.$memberChatData->name.'</p>
                                     <p class="webNamePara">
                                          <small>'.$memberChatData->webinar_name.'</samll>
                                             <span class="unreadMessage1">'.$unreadMessage->totalRow.'</span>
                                     </p>

                                 </div>
                              </div> 
                              </span>
                          </li>';
          }
        echo  $htmlData2 ; 
        
        
   
}elseif($_POST["conditionType"]==3){

  $date_time = date('d-m-Y H:i:s');
  $msg_time = date('h:i A', strtotime($date_time));

  $query = "INSERT INTO ".$table_name_chat." ( `member_id`,`msg_conservation`, `message`, `date_time`,`msg_time`, `messageStatus`, `token_id`) VALUES ( '".$_POST["member_id"]."','".$_POST["msg_conservation"]."','".$_POST["message"]."', '".$date_time."', '".$msg_time."','".$_POST["messageStatus"]."', '".$_POST["token_id"]."');";
  $wpdb->query($query) ;
  $lastid = $wpdb->insert_id;

  $sql = "SELECT * FROM `".$table_name_chat."` WHERE  `member_id` = ".$_POST["member_id"];
  $chatData = $wpdb->get_results($sql) ;
  $html = '';
    foreach($chatData as $key => $value) {
            if($value->msg_conservation ==1){
              $htmlClass = 'msj-rta macro';
            }else{
              $htmlClass = 'msj macro';
            }
             $html .='<li style="width:100%">
                      <div class="'.$htmlClass.'">
                         <div class="text text-l">
                             <p>'.$value->message.'</p>
                          <p><small>'.$value->msg_time.'</small>
                             </p>
                         </div>
                      </div>
                  </li>';
            }
          
    $updateSql = "UPDATE `".$table_name_chat."` SET `admin_read_status` = '1.' WHERE `admin_read_status` = 0 AND `member_id` = ".$_POST["member_id"]; 
    $wpdb->query($updateSql) ;
  if($lastid){
      echo $html;
   }
   
   
}elseif($_POST["conditionType"]==4){
  
  $sql = "SELECT * FROM `".$table_name_chat."` WHERE `read_status` = 0  AND `member_id` = ".$_POST["member_id"]  ;
  $chatData = $wpdb->get_results($sql) ;
  $html = '';
    foreach ($chatData as $key => $value) {
            if($value->msg_conservation ==1){
              $htmlClass = 'msj  macro';
            }else{
              $htmlClass = 'msj-rta  macro';
            }
             $html .='<li style="width:100%">
                      <div class="'.$htmlClass.'">
                         <div class="text text-l">
                             <p>'.$value->message.'</p>
                             <p><small>'.$value->msg_time.'</small>
                             </p>
                         </div>
                      </div>
                  </li>';
            }
    echo $html;
    $updateSql = "UPDATE `".$table_name_chat."` SET `read_status` = '1' WHERE `read_status` = 0 AND `member_id` = ".$_POST["member_id"]; 
    $wpdb->query($updateSql) ;

}elseif($_POST["conditionType"]==5){
  $sql = "SELECT * FROM `".$table_name_chat."` WHERE `admin_read_status` = 0  AND `member_id` = ".$_POST["member_id"]  ;
  $chatData = $wpdb->get_results($sql) ;
  $html = '';
    foreach ($chatData as $key => $value) {
            if($value->msg_conservation ==1){
              $htmlClass = 'msj-rta  macro';
            }else{
              $htmlClass = 'msj  macro';
            }
             $html .='<li style="width:100%">
                      <div class="'.$htmlClass.'">
                         <div class="text text-l">
                             <p>'.$value->message.'</p>
                             <p><small>'.$value->msg_time.'</small>
                             </p>
                         </div>
                      </div>
                  </li>';
            }
    echo $html;
    $updateSql = "UPDATE `".$table_name_chat."` SET `admin_read_status` = '1' WHERE `admin_read_status` = 0 AND `member_id` = ".$_POST["member_id"]; 
    $wpdb->query($updateSql) ;

}elseif($_POST["conditionType"]==6){
    /*$sql2 = "SELECT `id`,`webinar_id`,`name`,`email`,`webinar_type`, (SELECT `name` FROM `".$wpdb->prefix."vit_webinars` WHERE `id` = `webinar_id` ) as webinar_name    FROM `".$wpdb->prefix."vit_webinar_members` as  swm  WHERE `id` =".$_POST["member_id"] ;*/

    $sql2 = "SELECT * FROM `".$wpdb->prefix."vit_chat_users` as  swm  WHERE `id` =".$_POST["member_id"];

    $memberChatData = $wpdb->get_row($sql2);
     echo $memberChatData->name ;
   //print_r($memberChatData);

}elseif($_POST["conditionType"]==7){
    $sql = "SELECT `member_id` FROM `".$table_name_chat."` GROUP BY `member_id` ORDER BY `id` DESC";
    $chatMemeberIdData = $wpdb->get_results($sql);
     
     //  print_r($chatMemeberIdData);   

    $chatData = $wpdb->get_results($sql);
          foreach ($chatMemeberIdData as $key => $value) {
              
             // echo $value->member_id ;
          /*$sql2 = "SELECT `id`,`webinar_id`,`name`,`email`,`webinar_type`, (SELECT `name` FROM `".$wpdb->prefix."vit_webinars` WHERE `id` = `webinar_id` ) as webinar_name    FROM `".$wpdb->prefix."vit_webinar_members` as  swm  WHERE `id` =".$value->member_id ;*/
        $sql2 = "SELECT * FROM `".$wpdb->prefix."vit_chat_users` as  swm  WHERE `id` =".$_POST["member_id"];

          $memberChatData = $wpdb->get_row($sql2);
            $query2 = "SELECT count(*) as totalRow FROM `".$table_name_chat."` WHERE admin_read_status = 0 AND member_id =".$value->member_id ;
              $unreadMessage = $wpdb->get_row($query2);
            $htmlData2 .='<li style="width:100%" id="dsanndsanas">
                          <span style="cursor:pointer" onclick="allMessage('.$memberChatData->id.')">
                              <div class="msjAdmin macro ">
                                 <div class="textAdmin text text-l">
                                     <p style="font-weight: bold;">'.$memberChatData->name.'</p>
                                     <p class="webNamePara">
                                          <small>'.$memberChatData->name.'</samll>
                                             <span class="unreadMessage1">'.$unreadMessage->totalRow.'</span>
                                     </p>

                                 </div>
                              </div> 
                              </span>
                          </li>';
          }
        echo  $htmlData2 ; 
        
        
}
	

?>