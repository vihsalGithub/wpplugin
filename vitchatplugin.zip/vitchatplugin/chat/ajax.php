<?php

include_once('../../../../wp-config.php');
include_once('../../../../wp-load.php');
include_once('../../../../wp-includes/wp-db.php');
	$date_time = date('d-m-Y H:i:s');
	$msg_time = date('h:i A', strtotime($date_time)); 
	global $wpdb;

	$table_name_chat = $wpdb->prefix . "vit_chat_messages";
	




	$query = "INSERT INTO ".$table_name_chat." ( `member_id`, `message`, `date_time`,`msg_time`, `messageStatus`, `token_id`) VALUES ( '".$_POST["member_id"]."','".$_POST["message"]."', '".$date_time."', '".$msg_time."','".$_POST["messageStatus"]."', '".$_POST["token_id"]."');";
	$wpdb->query($query) ;
	$lastid = $wpdb->insert_id;

	$sql = "SELECT * FROM `".$table_name_chat."` WHERE `read_status` = 0 AND `member_id` = ".$_POST["member_id"];

	$chatData = $wpdb->get_results($sql) ;
	$html = '';
	  foreach ($chatData as $key => $value) {
	  				if($value->msg_conservation ==1){
                          $htmlClass = 'msj macro';
                        }else{
                          $htmlClass = 'msj-rta  macro';
                        }
                   $html .='<li style="width:100%">
                            <div class="'.$htmlClass.'">
                               <div class="text text-l">
                                   <p>'.$value->message.'</p>
                             		<p><small>'.$value->msg_time.'</small>
                                   </p>
                               </div>
                            </div>
                        </li>';
                }

    
    $updateSql = "UPDATE `".$table_name_chat."` SET `read_status` = '1.' WHERE `read_status` = 0 AND `member_id` = ".$_POST["member_id"]; 
    $wpdb->query($updateSql) ;
	   
	if($lastid){
   	//	$BlogName = get_bloginfo();
   		//echo $BlogName;
   		$jsonArray = array(
   			'status'=>true,
   			'message'=>'inserted',
   			'data'=>$html,
   		) ;

   		//echo json_encode($jsonArray);
   		echo $html;
   }
	




	
?>