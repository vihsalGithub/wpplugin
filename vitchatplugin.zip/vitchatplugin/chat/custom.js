

function openForm(memberID) {
  document.getElementById("myForm").style.display = "block";
  jQuery(".reLoadScriptMember").text('');
  var script = "<script>setInterval(function(){allMessageMemeber("+memberID+")}, 5000);</script>";
  jQuery(".reLoadScriptMember").append(script);
}
function closeForm() {
  document.getElementById("myForm").style.display = "none";
    jQuery(".reLoadScriptMember").text('');
}


/*jQuery(window).click(function(e) {
   allMessage(id);
});*/

jQuery("#submitMessage").click(function(){
    $message = jQuery("#messageInput").val();
        if($message != ''){
            jQuery.ajax({
            type:"post",
            data: jQuery("#chatMsgForm").serialize(),
            url:  plugin_url_chat,
            success:function(data){
                //alert(data);
                console.log(data);
                jQuery("#messageInput").val("");
                jQuery("#messageInput").removeAttr('value');
                jQuery("#mainContainerUl").append(data);
                var messageBody = document.querySelector('#mainContainerUl');
                messageBody.scrollTop = messageBody.scrollHeight - messageBody.clientHeight;
                //allMessage(id);
            }
        });
        }else{
            alert("Plese Fill input box");
        }
    
});





jQuery("#formUser").keypress(function(e) {
        if(e.which == 13) {
        $message = jQuery("#messageInput").val();
        if($message != ''){
            jQuery.ajax({
            type:"post",
            data: jQuery("#chatMsgForm").serialize(),
            url:  plugin_url_chat,
            success:function(data){
                //alert(data);
                console.log(data);
                jQuery("#messageInput").text('');
                jQuery("#messageInput").val('');
                jQuery("#mainContainerUl").append(data);
                var messageBody = document.querySelector('#mainContainerUl');
                messageBody.scrollTop = messageBody.scrollHeight - messageBody.clientHeight;
            
            }
        });
        
            return false;
        }else{
            alert("Plese Fill input box");
        }
    }
});



jQuery("#formAdmin").keypress(function(e) {
     if(e.which == 13) {
        $message = jQuery("#messageInput").val();
        if($message != ''){
             var member_id = jQuery("#member_id").val();
            var message = jQuery("#messageInput").val();
            var messageStatus = jQuery("#messageStatus").val();
            var token_id = jQuery("#token_id").val();
            var msg_conservation = jQuery("#msg_conservation").val();
                    /*data:jQuery("#chatMsgForm").serialize(),*/
            jQuery.ajax({
                type:"post",
                data:{member_id:member_id,message:message,messageStatus:messageStatus,token_id:token_id,msg_conservation:msg_conservation,conditionType:3},
                url:plugin_url_chat_admin,
                success:function(data){
                    console.log(data);
                    jQuery("#mainContainerUl").text('');
                    jQuery("#mainContainerUl").append(data);
                    jQuery("#messageInput").val("");
                    jQuery("#messageInput").removeAttr('value');
                     jQuery("#member_id").val('');
                    jQuery("#member_id").val(member_id);
                    var messageBody = document.querySelector('#mainContainerUl');
            messageBody.scrollTop = messageBody.scrollHeight - messageBody.clientHeight;
            
                }
            });
            return false;
            //alert();
        }else{
            alert("Plese Fill input box");
        }
    }
});

/***********************************************************/

jQuery(document).ready(function(){
    jQuery(".submitMsgAdmin").hide();
    jQuery("#submitBtnAdmin").hide();
    jQuery("#backBtnAdmin").hide();
    
});

//jQuery("#mainContainerUl").animate({ scrollTop: jQuery(document).height() }, "slow");


function allMessage(id){
    mesgMainBodyAction();
    jQuery.ajax({
        type:"post",
        data:{member_id:id,conditionType:1},
        url:plugin_url_chat_admin,
        success:function(data){
           // alert(data);
            selctUserName(id)
            jQuery(".reLoadScriptAdmin").text('');
            var script = "<script>setInterval(function(){allMessageAdmin("+id+")}, 5000);</script>";
            jQuery(".reLoadScriptAdmin").append(script);
            console.log(data);
            jQuery("#mainContainerUl").text('');
            jQuery("#mainContainerUl").append(data);
            jQuery(".submitMsgAdmin").show();
            jQuery("#submitBtnAdmin").show();
            jQuery("#backBtnAdmin").show();
            jQuery("#member_id").val('');
            jQuery("#member_id").val(id);
            var messageBody = document.querySelector('#mainContainerUl');
            messageBody.scrollTop = messageBody.scrollHeight - messageBody.clientHeight;


        }
    });
}




jQuery("#backBtnAdmin").click(function(){
    mesgMainBodyActionBack();
    jQuery.ajax({
        type:"post",
        data:{conditionType:2},
        url:plugin_url_chat_admin,
        success:function(data){
            jQuery("#selctUserName").text('');
            jQuery("#selctUserName").append('All Members Messages');
            console.log(data);
            jQuery(".reLoadScriptAdmin").text('');
            jQuery("#mainContainerUl").text('');
            jQuery("#mainContainerUl").append(data);
            jQuery(".submitMsgAdmin").hide();
            jQuery("#submitBtnAdmin").hide();
            jQuery("#backBtnAdmin").hide();
            var messageBody = document.querySelector('#mainContainerUl');
            messageBody.scrollTop = messageBody.scrollHeight - messageBody.clientHeight;
           
        }
    });
});




jQuery("#submitBtnAdmin").click(function(){
    var member_id = jQuery("#member_id").val();
    var message = jQuery("#messageInput").val();
    var messageStatus = jQuery("#messageStatus").val();
    var token_id = jQuery("#token_id").val();
    var msg_conservation = jQuery("#msg_conservation").val();
            /*data:jQuery("#chatMsgForm").serialize(),*/
    jQuery.ajax({
        type:"post",
        data:{member_id:member_id,message:message,messageStatus:messageStatus,token_id:token_id,msg_conservation:msg_conservation,conditionType:3},
        url:plugin_url_chat_admin,
        success:function(data){
            console.log(data);
            jQuery("#mainContainerUl").text('');
            jQuery("#mainContainerUl").append(data);
            jQuery("#messageInput").val("");
            jQuery("#messageInput").removeAttr('value');
             jQuery("#member_id").val('');
            jQuery("#member_id").val(member_id);
            var messageBody = document.querySelector('#mainContainerUl');
            messageBody.scrollTop = messageBody.scrollHeight - messageBody.clientHeight;
        }
    });
});




function allMessageMemeber(id){
    jQuery.ajax({
        type:"post",
        data:{member_id:id,conditionType:4},
        url:plugin_url_chat_admin,
        success:function(data){
            console.log(data);
            jQuery("#mainContainerUl").append(data);
           // var messageBody = document.querySelector('#mainContainerUl');
           // messageBody.scrollTop = messageBody.scrollHeight - messageBody.clientHeight;
           // jQuery("#member_id").val('');
          //  jQuery("#member_id").val(id);
        }
    });
}

function allMessageAdmin(id){
    jQuery.ajax({
        type:"post",
        data:{member_id:id,conditionType:5},
        url:plugin_url_chat_admin,
        success:function(data){
            console.log(data);
            jQuery("#mainContainerUl").append(data);
        }
    });
}



function selctUserName(id){
   // alert("nsdk");
    jQuery.ajax({
        type:"post",
        data:{member_id:id,conditionType:6},
        url:plugin_url_chat_admin,
        success:function(data){
            console.log(data);
            jQuery("#selctUserName").text('');
            jQuery("#selctUserName").append(data);
        }
    });
}

function adminLoginCheck(id){
   // alert("nsdk");
    jQuery.ajax({
        type:"post",
        url:adminLoginCheck_url,
        success:function(data){
            console.log(data);
            jQuery("#adminLoginStatus").text('');
            jQuery("#adminLoginStatus").append(data);
        }
    });
}


function adminGroupByMessage(){
   // alert("nsdk");
    jQuery.ajax({
        type:"post",
        data:{conditionType:7},
         url:plugin_url_chat_admin,
        success:function(data){
            console.log(data);
            jQuery("#selctUserName").text('');
            jQuery("#selctUserName").append('All Members Messages');
            console.log(data);
            jQuery(".reLoadScriptAdmin").text('');
            jQuery("#mainContainerUl").text('');
            jQuery("#mainContainerUl").append(data);
            jQuery(".submitMsgAdmin").hide();
            jQuery("#submitBtnAdmin").hide();
            jQuery("#backBtnAdmin").hide();
            var messageBody = document.querySelector('#mainContainerUl');
            messageBody.scrollTop = messageBody.scrollHeight - messageBody.clientHeight;
        }
    });
}


/***********************************************************/


function mesgMainBodyAction(){
    clearInterval(myVarInterval);
    jQuery(".mainBodyDiv").text('');
}
function mesgMainBodyActionBack(){
    //alert("Back");
    jQuery(".mainBodyDiv").text('');
    jQuery(".mainBodyDiv").append('<script>var myVarInterval =  setInterval(function(){ adminGroupByMessage()}, 5000)</script>');

}

