<?php

include_once('../../../../wp-config.php');
include_once('../../../../wp-load.php');
include_once('../../../../wp-includes/wp-db.php');

  global $wpdb;
  
 
  //echo $sql ;

if($_GET['message'] ==1){

  $Query = "UPDATE `{$wpdb->prefix}vit_admin_login_status` SET `admin_status` = '0' WHERE `{$wpdb->prefix}vit_admin_login_status`.`id` = 1;";
  $wpdb->query($Query);
  $redirectUrl = site_url('/')."wp-admin";
  header('Location:'.$redirectUrl);


}else{
    $table_name_chat1 = $wpdb->prefix . "vit_admin_login_status";
    $sql = "SELECT * FROM `".$table_name_chat1."` WHERE `admin_status` = 1 ";
    $data = $wpdb->get_row($sql);

    $chatSettData = $wpdb->get_row("SELECT `chat_usrMsgAdmOfline`,`chat_usrMsgAdmOnline` FROM `{$wpdb->prefix}vit_chatbox_setting` where  `id`=1");

    if(count($data)>0){
      echo '<span style="height: 10px;width: 10px;background-color: #4CAF50;border-radius: 50%;display: inline-block;"></span>'.$chatSettData->chat_usrMsgAdmOnline;
    }else{
       echo '<span style="height: 10px;width: 10px;background-color: #f44336;border-radius: 50%;display: inline-block;"></span>'.$chatSettData->chat_usrMsgAdmOfline;
    }
}

 

?>