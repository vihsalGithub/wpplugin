<?php
wp_enqueue_style( 'custom', plugins_url( 'chat/custom.css', __FILE__ ) );
    
  /*chat box Setting*/
    $vit_chatbox_setting = $wpdb->prefix . "vit_chatbox_setting";
    $chatSettSql = "SELECT * FROM `".$vit_chatbox_setting."` WHERE `id` = 1";
    $chatSettData = $wpdb->get_row($chatSettSql);
    //print_r($chatSettData);
    echo '<style>
    .msjAdmin {background: #'.$chatSettData->chat_textAreaColor.' !important;}
    .msj {background: #'.$chatSettData->chat_textAreaColor.' !important;}
    .msj-rta {background: #'.$chatSettData->chat_textAreaColor.' !important;}
    .msj-rta::after{border-color:#'.$chatSettData->chat_textAreaColor.' whitesmoke #'.$chatSettData->chat_textAreaColor.'transparent #'.$chatSettData->chat_textAreaColor.' transparent #'.$chatSettData->chat_textAreaColor.' transparent  !important;}
    .msj::before{border-right-color: #'.$chatSettData->chat_textAreaColor.' !important;}
    .msj-rta::after{ border-top-color: #'.$chatSettData->chat_textAreaColor.'  !important;}
    .text > p:last-of-typ{color:  #'.$chatSettData->chat_textColor.'  !important;}
    #chatMsgForm p{color:  #'.$chatSettData->chat_textColor.'  !important;}
    .chat-popup{border: 2px solid #'.$chatSettData->chat_boxBorderColor.' !important;}
    #chatMsgForm{background:#'.$chatSettData->chat_mainBgColor.' !important;}
    #chatMsgForm h1{background-color: #'.$chatSettData->chat_textAreaColor.'!important;color: #'.$chatSettData->chat_textColor.';}
    #backBtnAdmin{color: #'.$chatSettData->chat_backTextColor.'!important;}
    .open-button{background-color: #'.$chatSettData->chat_mainBgColor.'!important;color: #'.$chatSettData->chat_textColor.'  !important;}
    </style>';
    /*chat box Setting*/


$table_name_chat = $wpdb->prefix . "vit_chat_messages";
$sql = "SELECT * FROM `".$table_name_chat."` WHERE  `member_id` = ".$_SESSION['session_variable_id'];
$chatData = $wpdb->get_results($sql);


$table_name_chat = $wpdb->prefix . "vit_chat_users";
//echo $table_name_chat ;
$sql1 = "SELECT * FROM `".$table_name_chat."` WHERE  `id` = 1";
$memdata = $wpdb->get_row($sql1);
    //    print_r($memdata);
$_SESSION['session_variable_id'] =  $memdata->id;
$_SESSION['chat_user_status'] =  $memdata->id;
$_SESSION['chat_user_name'] =  $memdata->name;
$_SESSION['chat_user_contact'] =  $memdata->contact_no;

   // echo  '<style> #chatMsgForm{background-image:url("'.plugins_url( 'includes/chat/images/chattheme.jpg', __FILE__ ).'") !important ;}</style>' ;
if($_SESSION['chat_user_status']){
        $javascript = '
            <button class="open-button" onclick="openForm('.$_SESSION['session_variable_id'].')">Chat</button>
                <div class="chat-popup" id="myForm"><div id="formUser">
              <form  id="chatMsgForm" class="form-container" method="post">
                <h1>Chat</h1>
                  <div id="adminLoginStatus"></div>
                <div id="mainContainer" >';

                $javascript .='<ul id="mainContainerUl">';
                    foreach ($chatData as $key => $value) {
                        if($value->msg_conservation ==1){
                          $htmlClass = 'msj macro';
                        }else{
                          $htmlClass = 'msj-rta  macro';
                        }
                        $javascript .='<li style="width:100%">
                            <div class="'.$htmlClass.'">
                               <div class="text text-l">
                                   <p>'.$value->message.'</p>
                                   <p style="line-height: 20px;font-size: 15px;"><small>'.$value->msg_time.'</small>
                                   </p>
                               </div>
                            </div>
                        </li>';
                    }
                $javascript .='</ul>';
                $javascript .='</div><div class="chatText">
                    <label for="msg"><b>Message</b></label>

                    <input type="text"  class="inputfield" placeholder="Type message.."   id="messageInput" name="message" required / >
                     <input type="hidden" placeholder="member_id" name="member_id" value="'.$_SESSION['session_variable_id'].'" / >
                     <input type="hidden" placeholder="userid" name="messageStatus" value="1" / >
                     <input type="hidden" placeholder="token_id" name="token_id" value="12345" / >
                    </div>
                    <button type="button" name="submitMessage"  id="submitMessage" class="submitMessage btnClass btnSend" style="background:#'.$chatSettData->chat_sendBtnColor.'">Send</button>
                    <button type="button" class="submitMessage btnClass btnClose" onclick="closeForm()"style="background:#'.$chatSettData->chat_closeBtnColor.'">Close</button>
                   </div></form>



                </div>';
        $javascript.='<div class="reLoadScriptMember"></div>';
}

    wp_enqueue_script( 'custom-script1', plugins_url( 'chat/custom.js', __FILE__ ));
      $javascript.='<script>var plugin_url_chat = "'.plugins_url( 'chat/ajax.php', __FILE__ ).'" </script>';
      $javascript.='<script>var plugin_url_chat_admin = "'.plugins_url( 'chat/ajaxAdmin.php',__FILE__).'" </script>';
      $javascript.='<script>var adminLoginCheck_url = "'.plugins_url( 'chat/adminLoginCheck.php',__FILE__).'" </script>';
      $javascript.='<script>setInterval(function(){adminLoginCheck()}, 5000)</script>';
      echo $javascript ;



?>