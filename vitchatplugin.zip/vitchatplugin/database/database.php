<?php
/*chat table Create*/
   $chat_table = $wpdb->prefix . 'vit_chat_messages';
        $chatQueryCreate = "CREATE TABLE `".$chat_table."` (
                          `id` int(11)  NOT NULL AUTO_INCREMENT,
                          `member_id` int(11) NOT NULL,
                          `msg_conservation` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=user,1=admin',
                          `message` text NOT NULL,
                          `date_time` varchar(255) NOT NULL,
                          `msg_time` varchar(255) NOT NULL,
                          `messageStatus` int(11) NOT NULL DEFAULT '1',
                          `token_id` int(11) NOT NULL,
                          `read_status` int(11) NOT NULL DEFAULT '0',
                          `admin_read_status` int(11) NOT NULL DEFAULT '0'
                          , PRIMARY KEY (`id`)
                        ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
       dbDelta($chatQueryCreate); 
      $chatBoxSetQuery = "CREATE TABLE `".$wpdb->prefix."vit_chatbox_setting` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `chat_edate` varchar(150) NOT NULL,
                            `chat_mainTitle` varchar(255) NOT NULL,
                            `chat_sendBtnText` varchar(100) NOT NULL,
                            `chat_closeBtnText` varchar(100) NOT NULL,
                            `chat_sendBtnColor` varchar(100) NOT NULL,
                            `chat_closeBtnColor` varchar(100) NOT NULL,
                            `chat_boxBorderColor` varchar(100) DEFAULT NULL,
                            `chat_mainBgColor` varchar(100) NOT NULL,
                            `chat_textAreaColor` varchar(100) NOT NULL,
                            `chat_textColor` varchar(100) NOT NULL,
                            `chat_backTextColor` varchar(100) DEFAULT NULL,
                            `chat_usrMsgAdmOfline` varchar(255) DEFAULT NULL,
                            `chat_usrMsgAdmOnline` varchar(255) DEFAULT NULL
                            , PRIMARY KEY (`id`)
                          ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
      dbDelta($chatBoxSetQuery); 

       
       $chatBoxDefValQuery =  "INSERT INTO `".$wpdb->prefix."vit_chatbox_setting` (`id`, `chat_edate`, `chat_mainTitle`, `chat_sendBtnText`, `chat_closeBtnText`, `chat_sendBtnColor`, `chat_closeBtnColor`, `chat_boxBorderColor`, `chat_mainBgColor`, `chat_textAreaColor`, `chat_textColor`, `chat_backTextColor`, `chat_usrMsgAdmOfline`, `chat_usrMsgAdmOnline`) VALUES
          (1, '', 'All Members Messages', 'Send', 'Close', '008CBA', 'f44336', 'f44336', '868680', 'ffffff', '000000', '000000', 'Offline', 'Online');" ;




      $chatBoxAdminLoginQuery =  "CREATE TABLE `".$wpdb->prefix."vit_admin_login_status` (
                                `id` int(11) NOT NULL AUTO_INCREMENT,
                                `admin_status` int(11) NOT NULL,
                                `chat_time` int(11) NOT NULL
                            , PRIMARY KEY (`id`)
                              ) ENGINE=InnoDB DEFAULT CHARSET=latin1;" ;
      dbDelta($chatBoxAdminLoginQuery); 

      $chatBoxDefValAdminLoginInsertQuery =  "INSERT INTO `".$wpdb->prefix."vit_admin_login_status` 
      (`id`, `admin_status`, `chat_time`) 
      VALUES (NULL, '1', '1547196569');" ;
      dbDelta($chatBoxDefValAdminLoginInsertQuery); 
      
      $chatBoxVitChatBoxUserQuery =  "CREATE TABLE `".$wpdb->prefix."vit_chat_users` (
                                `id` int(11) NOT NULL AUTO_INCREMENT,
                                `name` varchar(255) DEFAULT NULL,
                                `contact_no` varchar(255) DEFAULT NULL,
                                `mobile_otp` varchar(255) DEFAULT NULL,
                                `password` varchar(255) DEFAULT NULL,
                            , PRIMARY KEY (`id`)
                              ) ENGINE=InnoDB DEFAULT CHARSET=latin1;" ;
      dbDelta($chatBoxVitChatBoxUserQuery);
      $chatBoxDefValVitChatBoxInsertQuery =  "INSERT INTO `".$wpdb->prefix."vit_chat_users` 
            (`id`, `name`, `contact_no`, `mobile_otp`, `password`) 
          VALUES (NULL, 'vishal', '9876543210', '1234', '1234');" ;
      dbDelta($chatBoxDefValVitChatBoxInsertQuery); 


/*chat table Create End*/
?>