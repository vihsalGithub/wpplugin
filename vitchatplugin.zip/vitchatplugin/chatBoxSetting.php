<?php
	 
	 wp_enqueue_style( 'colorpicker-css', plugins_url( 'chat/colorpicker/css/colorpicker.css',__FILE__ ) );
   wp_enqueue_script( 'jquery-js', plugins_url( 'chat/colorpicker/js/jquery.js' ,__FILE__) );
	 wp_enqueue_script( 'colorpicker-js', plugins_url( 'chat/colorpicker/js/colorpicker.js' ,__FILE__) );
	 wp_enqueue_script( 'eye-js', plugins_url( 'chat/colorpicker/js/eye.js',__FILE__ ) );
	 wp_enqueue_script( 'layout-js', plugins_url( 'chat/colorpicker/js/layout.js?ver=1.0.2' ,__FILE__) );

if(isset($_POST['chatSetfrmUpdate'])){
		//echo "submit";
      $query = "UPDATE `{$wpdb->prefix}vit_chatbox_setting` SET 
        `chat_mainTitle`= '$_REQUEST[chat_mainTitle]', 
        `chat_sendBtnText`= '$_REQUEST[chat_sendBtnText]', 
        `chat_closeBtnText`= '$_REQUEST[chat_closeBtnText]', 
        `chat_sendBtnColor`= '$_REQUEST[chat_sendBtnColor]', 
        `chat_boxBorderColor`= '$_REQUEST[chat_boxBorderColor]', 
        `chat_closeBtnColor`= '$_REQUEST[chat_closeBtnColor]', 
        `chat_mainBgColor`= '$_REQUEST[chat_mainBgColor]', 
        `chat_textAreaColor`= '$_REQUEST[chat_textAreaColor]', 
        `chat_textColor`= '$_REQUEST[chat_textColor]',
        `chat_backTextColor`= '$_REQUEST[chat_backTextColor]',
        `chat_usrMsgAdmOfline`= '$_REQUEST[chat_usrMsgAdmOfline]',
        `chat_usrMsgAdmOnline`= '$_REQUEST[chat_usrMsgAdmOnline]'
        WHERE  `{$wpdb->prefix}vit_chatbox_setting`.`id` =1";
          $wpdb->query($query);

	}
  global $wpdb;
$chatSettData = $wpdb->get_row("SELECT * FROM `{$wpdb->prefix}vit_chatbox_setting` where  `id`=1");
    $chatSettTable = $wpdb->prefix."vit_chatbox_setting";
    $redirectUrl = plugins_url( 'chat/adminLoginCheck.php?message=1') ;
    //echo $redirectUrl ;
?>
<!-- <a  class="button-primary action" href="<?php echo wp_logout_url( 'http://multisiteparent.com' ); ?>">Logout</a> -->
<a  class="button-primary action" href="<?php echo wp_logout_url( $redirectUrl); ?>">Logout</a>

<div class="container">
  <h1>Chat Box Setting</h1>
  <form id="chatSettingForm" name="chatSettingForm" method="post" > 
  <table class="vpp_form_table" cellpadding="0" cellspacing="5"><tbody><tr>
  	<tbody>
  		<tr>
  			<th>Main Title  Text</th>
  			<td><input type="text" name="chat_mainTitle"  id="chat_mainTitle"  required placeholder="All Members Messages" value="<?php  echo (!empty($chatSettData->chat_mainTitle)) ? $chatSettData->chat_mainTitle : "All Members Messages"   ?>" /></td>
  		</tr>
  		
  		<tr>
  			<th><div class="colorpicker1">Send Button Text</div></th>
  			<td><input type="text" name="chat_sendBtnText"  id="chat_sendBtnText"  required placeholder="Send" value="<?php echo (!empty($chatSettData->chat_sendBtnText)) ? $chatSettData->chat_sendBtnText : "Send"   ?>" /></td>
  		</tr>
  		<tr>
  			<th><div class="colorpicker1">Close Button Text</div></th>
  			<td><input type="text" name="chat_closeBtnText"  id="chat_closeBtnText"  required placeholder="Close" value="<?php echo (!empty($chatSettData->chat_closeBtnText)) ? $chatSettData->chat_closeBtnText : "Close"   ?>" /></td>
  		</tr>
  		<tr>
  			<th> 
          <div class="colorpicker1">Send Button Colour</div>
           <div class="colorBox" style="width:10px;height:10px;float:right;background-color: #<?php echo (!empty($chatSettData->chat_sendBtnColor)) ? $chatSettData->chat_sendBtnColor: "008CBA"  ?>"></div>
        </th>
  			<td><input type="text" onchange="sendBtnColor()" name="chat_sendBtnColor" class="colorpickerField"  id="chat_sendBtnColor"  required placeholder="Send" value="<?php echo (!empty($chatSettData->chat_sendBtnColor)) ? $chatSettData->chat_sendBtnColor: "008CBA"  ?>" /></td>
  		</tr>
  		<tr>
        <th>
          <div class="colorpicker1">Close Button Colour</div>
          <div class="colorBox" style="width:10px;height:10px;float:right;background-color: #<?php echo (!empty($chatSettData->chat_closeBtnColor)) ? $chatSettData->chat_closeBtnColor : "f44336"  ?>" ></div>
        </th>
        <td><input type="text" name="chat_closeBtnColor"   class="colorpickerField"  id="chat_closeBtnColor"  required placeholder="Close Button Colour" value="<?php echo (!empty($chatSettData->chat_closeBtnColor)) ? $chatSettData->chat_closeBtnColor : "f44336"  ?>" /></td>
      </tr>

      <tr>
  			<th>
          <div class="colorpicker1">Box Boder Colour</div>
          <div class="colorBox" style="width:10px;height:10px;float:right;background-color: #<?php echo (!empty($chatSettData->chat_boxBorderColor)) ? $chatSettData->chat_boxBorderColor : "f44336"  ?>" ></div>
        </th>
  			<td><input type="text" name="chat_boxBorderColor"   class="colorpickerField"  id="chat_boxBorderColor"  required placeholder="Close Button Colour" value="<?php echo (!empty($chatSettData->chat_boxBorderColor)) ? $chatSettData->chat_boxBorderColor : "f44336"  ?>" /></td>
  		</tr>

  		<tr>
  			<th>
          <div class="colorpicker1">Main Background Colour</div>
          <div class="colorBox" style="width:10px;height:10px;float:right;background-color: #<?php echo (!empty($chatSettData->chat_mainBgColor)) ? $chatSettData->chat_mainBgColor : "868680"  ?>" ></div>
        </th>
  			<td><input type="text" name="chat_mainBgColor"  class="colorpickerField"   id="chat_mainBgColor"  required placeholder="Main Bg Colour" value="<?php echo (!empty($chatSettData->chat_mainBgColor)) ? $chatSettData->chat_mainBgColor : "868680"  ?>" /></td>
  		</tr>
  		<tr>
  			<th>
          <div class="colorpicker1">Text Area Colour</div>
          <div class="colorBox" style="width:10px;height:10px;float:right;background-color: #<?php echo (!empty($chatSettData->chat_textAreaColor))? $chatSettData->chat_textAreaColor: "ffffff"  ?>" ></div>
        </th>
  			<td><input type="text" name="chat_textAreaColor"  class="colorpickerField"   id="chat_textAreaColor"  required placeholder="Text Area Colour" value="<?php echo (!empty($chatSettData->chat_textAreaColor))? $chatSettData->chat_textAreaColor: "ffffff"  ?>" /></td>
  		</tr>
  		<tr>
        <th><div class="colorpicker1">Text  Colour</div>
          <div class="colorBox" style="width:10px;height:10px;float:right;background-color: #<?php echo (!empty($chatSettData->chat_textColor)) ? $chatSettData->chat_textColor: "000000"  ?>"></div></th>
        <td><input type="text" name="chat_textColor"  class="colorpickerField"   id="chat_textColor"  required placeholder="Text Colour" value="<?php echo (!empty($chatSettData->chat_textColor)) ? $chatSettData->chat_textColor: "000000"  ?>" /></td>
      </tr>
      <tr>
        <th><div class="colorpicker1">Back Text  Colour</div>
          <div class="colorBox" style="width:10px;height:10px;float:right;background-color: #<?php echo (!empty($chatSettData->chat_backTextColor)) ? $chatSettData->chat_backTextColor: "000000"  ?>"></div></th>
        <td><input type="text" name="chat_backTextColor"  class="colorpickerField"   id="chat_backTextColor"  required placeholder="Text Colour" value="<?php echo (!empty($chatSettData->chat_backTextColor)) ? $chatSettData->chat_backTextColor: "000000"  ?>" /></td>
      </tr>
      <tr>
        <th><div class="colorpicker1">Admin Offline Message</div></th>
        <td><input type="text" name="chat_usrMsgAdmOfline"  class="colorpickerField"   id="chat_usrMsgAdmOfline"  required placeholder="Text Colour" value="<?php echo (!empty($chatSettData->chat_usrMsgAdmOfline)) ? $chatSettData->chat_usrMsgAdmOfline: "Offline"  ?>" /></td>
      </tr>
      <tr>
  			<th><div class="colorpicker1">Admin Online Message</div></th>
  			<td><input type="text" name="chat_usrMsgAdmOnline"  class="colorpickerField"   id="chat_usrMsgAdmOnline"  required placeholder="Text Colour" value="<?php echo (!empty($chatSettData->chat_usrMsgAdmOnline)) ? $chatSettData->chat_usrMsgAdmOnline: "Online"  ?>" /></td>
  		</tr>

  	</tbody>
  </table>
  	<input type="button" class="button-primary action" name="chatSetfrmDefault" id="chatSetfrmDefault" value="Default">
    <input type="submit" class="button-primary action" name="chatSetfrmUpdate"  id="chatSetfrmUpdate" value="Update">
  </form>

  <script type="text/javascript">
    jQuery("#chatSetfrmDefault").click(function(){
        jQuery("#chat_mainTitle").val('All Members Messages') ;
        jQuery("#chat_sendBtnText").val('Send') ;
        jQuery("#chat_closeBtnText").val('Close') ;
        jQuery("#chat_sendBtnColor").val('008CBA') ;
        jQuery("#chat_boxBorderColor").val('f44336') ;
        jQuery("#chat_closeBtnColor").val('f44336') ;
        jQuery("#chat_mainBgColor").val('868680') ;
        jQuery("#chat_textAreaColor").val('ffffff') ;
        jQuery("#chat_textColor").val('000000') ;
        jQuery("#chat_backTextColor").val('000000') ;
        jQuery("#chat_usrMsgAdmOfline").val('Offline') ;
    });

  </script>

  <!-- Chatpage include -->
<?php

  include("adminChatBox.php");
    
?>
